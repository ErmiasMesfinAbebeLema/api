--
-- PostgreSQL database dump
--

\restrict p2K7DtxNaGuF9Fi8qRTUBhMse429kSU6oRKfaDhLj4nVBo5reiz4HH7nTMvzCyE

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: attendancestatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.attendancestatus AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'PRESENT',
    'ABSENT'
);


ALTER TYPE public.attendancestatus OWNER TO root;

--
-- Name: certificatestatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.certificatestatus AS ENUM (
    'ACTIVE',
    'REVOKED',
    'EXPIRED'
);


ALTER TYPE public.certificatestatus OWNER TO root;

--
-- Name: courseenrollmentstatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.courseenrollmentstatus AS ENUM (
    'PENDING',
    'ACTIVE',
    'COMPLETED',
    'DROPPED'
);


ALTER TYPE public.courseenrollmentstatus OWNER TO root;

--
-- Name: documenttype; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.documenttype AS ENUM (
    'NATIONAL_ID',
    'PASSPORT',
    'CONTRACT',
    'PROFILE_PHOTO',
    'GRADE_8_CERTIFICATE',
    'GRADE_10_CERTIFICATE',
    'GRADE_12_CERTIFICATE',
    'ETHIOPIAN_HIGHER_EDUCATION_ENTRANCE',
    'GRADE_REPORT',
    'EXPERIENCE_LETTER'
);


ALTER TYPE public.documenttype OWNER TO root;

--
-- Name: enrollmentstatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.enrollmentstatus AS ENUM (
    'PENDING',
    'ACTIVE',
    'GRADUATED',
    'SUSPENDED',
    'WITHDRAWN'
);


ALTER TYPE public.enrollmentstatus OWNER TO root;

--
-- Name: gender; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.gender AS ENUM (
    'MALE',
    'FEMALE',
    'OTHER'
);


ALTER TYPE public.gender OWNER TO root;

--
-- Name: invoicestatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.invoicestatus AS ENUM (
    'DRAFT',
    'SENT',
    'PAID',
    'CANCELLED',
    'COMPLETED'
);


ALTER TYPE public.invoicestatus OWNER TO root;

--
-- Name: paymentstatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.paymentstatus AS ENUM (
    'PENDING',
    'COMPLETED',
    'REFUNDED',
    'FAILED'
);


ALTER TYPE public.paymentstatus OWNER TO root;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'INSTRUCTOR',
    'STUDENT',
    'super_admin',
    'SUPER_ADMIN'
);


ALTER TYPE public.userrole OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.admin_permissions (
    id integer NOT NULL,
    admin_id integer NOT NULL,
    can_manage_users boolean NOT NULL,
    can_create_users boolean NOT NULL,
    can_edit_users boolean NOT NULL,
    can_delete_users boolean NOT NULL,
    can_manage_students boolean NOT NULL,
    can_view_students boolean NOT NULL,
    can_create_students boolean NOT NULL,
    can_edit_students boolean NOT NULL,
    can_delete_students boolean NOT NULL,
    can_manage_courses boolean NOT NULL,
    can_create_courses boolean NOT NULL,
    can_edit_courses boolean NOT NULL,
    can_delete_courses boolean NOT NULL,
    can_manage_certificates boolean NOT NULL,
    can_create_certificates boolean NOT NULL,
    can_edit_certificates boolean NOT NULL,
    can_delete_certificates boolean NOT NULL,
    can_revoke_certificates boolean NOT NULL,
    can_manage_enrollments boolean NOT NULL,
    can_create_enrollments boolean NOT NULL,
    can_edit_enrollments boolean NOT NULL,
    can_delete_enrollments boolean NOT NULL,
    can_manage_payments boolean NOT NULL,
    can_view_payments boolean NOT NULL,
    can_create_payments boolean NOT NULL,
    can_manage_invoices boolean NOT NULL,
    can_create_invoices boolean NOT NULL,
    can_edit_invoices boolean NOT NULL,
    can_delete_invoices boolean NOT NULL,
    can_manage_documents boolean NOT NULL,
    can_view_documents boolean NOT NULL,
    can_upload_documents boolean NOT NULL,
    can_delete_documents boolean NOT NULL,
    can_view_reports boolean NOT NULL,
    can_export_reports boolean NOT NULL,
    can_manage_instructors boolean NOT NULL,
    can_manage_settings boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    updated_by integer,
    can_view_email_logs boolean DEFAULT true NOT NULL,
    can_edit_email_logs boolean DEFAULT false NOT NULL
);


ALTER TABLE public.admin_permissions OWNER TO root;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_permissions_id_seq OWNER TO root;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.admin_permissions_id_seq OWNED BY public.admin_permissions.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO root;

--
-- Name: attendance_requests; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.attendance_requests (
    id integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    schedule_id integer NOT NULL,
    requested_date date NOT NULL,
    time_slot integer NOT NULL,
    status public.attendancestatus NOT NULL,
    notes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.attendance_requests OWNER TO root;

--
-- Name: attendance_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.attendance_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendance_requests_id_seq OWNER TO root;

--
-- Name: attendance_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.attendance_requests_id_seq OWNED BY public.attendance_requests.id;


--
-- Name: attendances; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.attendances (
    id integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    instructor_id integer,
    date date NOT NULL,
    time_slot integer NOT NULL,
    status public.attendancestatus NOT NULL,
    notes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.attendances OWNER TO root;

--
-- Name: attendances_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.attendances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendances_id_seq OWNER TO root;

--
-- Name: attendances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.attendances_id_seq OWNED BY public.attendances.id;


--
-- Name: certificate_templates; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.certificate_templates (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    html_content text NOT NULL,
    css_styles text,
    background_image_url character varying(500),
    is_active boolean NOT NULL,
    created_by integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.certificate_templates OWNER TO root;

--
-- Name: certificate_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.certificate_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.certificate_templates_id_seq OWNER TO root;

--
-- Name: certificate_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.certificate_templates_id_seq OWNED BY public.certificate_templates.id;


--
-- Name: certificates; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.certificates (
    id integer NOT NULL,
    certificate_number character varying(50) NOT NULL,
    student_id integer NOT NULL,
    template_id integer NOT NULL,
    course_id integer NOT NULL,
    issue_date date NOT NULL,
    expiry_date date,
    cert_metadata json,
    pdf_url character varying(500),
    status public.certificatestatus NOT NULL,
    revocation_reason text,
    revoked_by integer,
    revoked_at timestamp without time zone,
    issued_by integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.certificates OWNER TO root;

--
-- Name: certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.certificates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.certificates_id_seq OWNER TO root;

--
-- Name: certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.certificates_id_seq OWNED BY public.certificates.id;


--
-- Name: courses; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    duration_hours numeric(10,2),
    duration_text character varying(100),
    level character varying(50),
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.courses OWNER TO root;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.courses_id_seq OWNER TO root;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.email_logs (
    id integer NOT NULL,
    recipient_email character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    email_type character varying(50) NOT NULL,
    template_name character varying(100),
    body_text text,
    body_html text,
    context_data json,
    related_user_id integer,
    related_entity_type character varying(50),
    related_entity_id integer,
    status character varying(20) NOT NULL,
    error_message text,
    retry_count integer NOT NULL,
    last_retry_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    sent_at timestamp without time zone
);


ALTER TABLE public.email_logs OWNER TO root;

--
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.email_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_logs_id_seq OWNER TO root;

--
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.email_logs_id_seq OWNED BY public.email_logs.id;


--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.enrollments (
    id integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    status public.courseenrollmentstatus NOT NULL,
    enrolled_at timestamp without time zone NOT NULL,
    start_date date,
    completion_date date,
    grade character varying(10),
    attendance_percentage numeric(5,2),
    notes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    fee numeric(10,2)
);


ALTER TABLE public.enrollments OWNER TO root;

--
-- Name: enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.enrollments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.enrollments_id_seq OWNER TO root;

--
-- Name: enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.enrollments_id_seq OWNED BY public.enrollments.id;


--
-- Name: instructor_courses; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.instructor_courses (
    id integer NOT NULL,
    instructor_id integer NOT NULL,
    course_id integer NOT NULL,
    assigned_by integer,
    assigned_at timestamp without time zone NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.instructor_courses OWNER TO root;

--
-- Name: instructor_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.instructor_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.instructor_courses_id_seq OWNER TO root;

--
-- Name: instructor_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.instructor_courses_id_seq OWNED BY public.instructor_courses.id;


--
-- Name: instructor_schedules; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.instructor_schedules (
    id integer NOT NULL,
    instructor_id integer NOT NULL,
    course_id integer,
    date date NOT NULL,
    start_time integer NOT NULL,
    end_time integer NOT NULL,
    notes text,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.instructor_schedules OWNER TO root;

--
-- Name: instructor_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.instructor_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.instructor_schedules_id_seq OWNER TO root;

--
-- Name: instructor_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.instructor_schedules_id_seq OWNED BY public.instructor_schedules.id;


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoice_items (
    id integer NOT NULL,
    invoice_id integer NOT NULL,
    enrollment_id integer,
    description text NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    amount numeric(10,2) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO root;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_items_id_seq OWNER TO root;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    invoice_number character varying(50) NOT NULL,
    student_id integer NOT NULL,
    issue_date date NOT NULL,
    due_date date,
    total_amount numeric(10,2) NOT NULL,
    discount_amount numeric(10,2) NOT NULL,
    tax_amount numeric(10,2) NOT NULL,
    grand_total numeric(10,2) NOT NULL,
    status public.invoicestatus NOT NULL,
    notes text,
    pdf_url character varying(500),
    created_by integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.invoices OWNER TO root;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoices_id_seq OWNER TO root;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    link character varying(255),
    is_read boolean NOT NULL,
    created_by integer,
    read_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO root;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO root;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.payment_methods (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.payment_methods OWNER TO root;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_methods_id_seq OWNER TO root;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.payment_methods_id_seq OWNED BY public.payment_methods.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    student_id integer NOT NULL,
    enrollment_id integer,
    invoice_id integer,
    amount numeric(10,2) NOT NULL,
    payment_date date NOT NULL,
    payment_method_id integer NOT NULL,
    transaction_reference character varying(255),
    status public.paymentstatus NOT NULL,
    notes text,
    recorded_by integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO root;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO root;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: student_documents; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.student_documents (
    id integer NOT NULL,
    student_id integer NOT NULL,
    document_type public.documenttype NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    description text,
    uploaded_by integer,
    uploaded_at timestamp without time zone NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.student_documents OWNER TO root;

--
-- Name: student_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.student_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.student_documents_id_seq OWNER TO root;

--
-- Name: student_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.student_documents_id_seq OWNED BY public.student_documents.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.students (
    id integer NOT NULL,
    user_id integer NOT NULL,
    date_of_birth date,
    gender public.gender,
    emergency_contact_name character varying(200),
    emergency_contact_phone character varying(20),
    emergency_contact_relation character varying(50),
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state character varying(100),
    postal_code character varying(20),
    country character varying(100),
    enrollment_status public.enrollmentstatus DEFAULT 'PENDING'::public.enrollmentstatus NOT NULL,
    enrollment_date date,
    graduation_date date,
    program_type character varying(200),
    referral_source character varying(200),
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.students OWNER TO root;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO root;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255),
    password_hash character varying(255) NOT NULL,
    full_name character varying(200) NOT NULL,
    phone character varying(20),
    profile_photo_url character varying(500),
    bio text,
    role public.userrole DEFAULT 'STUDENT'::public.userrole NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    is_email_verified boolean DEFAULT false NOT NULL,
    email_verified_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO root;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO root;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admin_permissions id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_id_seq'::regclass);


--
-- Name: attendance_requests id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendance_requests ALTER COLUMN id SET DEFAULT nextval('public.attendance_requests_id_seq'::regclass);


--
-- Name: attendances id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendances ALTER COLUMN id SET DEFAULT nextval('public.attendances_id_seq'::regclass);


--
-- Name: certificate_templates id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificate_templates ALTER COLUMN id SET DEFAULT nextval('public.certificate_templates_id_seq'::regclass);


--
-- Name: certificates id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificates ALTER COLUMN id SET DEFAULT nextval('public.certificates_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: email_logs id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.email_logs ALTER COLUMN id SET DEFAULT nextval('public.email_logs_id_seq'::regclass);


--
-- Name: enrollments id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.enrollments ALTER COLUMN id SET DEFAULT nextval('public.enrollments_id_seq'::regclass);


--
-- Name: instructor_courses id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_courses ALTER COLUMN id SET DEFAULT nextval('public.instructor_courses_id_seq'::regclass);


--
-- Name: instructor_schedules id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_schedules ALTER COLUMN id SET DEFAULT nextval('public.instructor_schedules_id_seq'::regclass);


--
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: payment_methods id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN id SET DEFAULT nextval('public.payment_methods_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: student_documents id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.student_documents ALTER COLUMN id SET DEFAULT nextval('public.student_documents_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.admin_permissions (id, admin_id, can_manage_users, can_create_users, can_edit_users, can_delete_users, can_manage_students, can_view_students, can_create_students, can_edit_students, can_delete_students, can_manage_courses, can_create_courses, can_edit_courses, can_delete_courses, can_manage_certificates, can_create_certificates, can_edit_certificates, can_delete_certificates, can_revoke_certificates, can_manage_enrollments, can_create_enrollments, can_edit_enrollments, can_delete_enrollments, can_manage_payments, can_view_payments, can_create_payments, can_manage_invoices, can_create_invoices, can_edit_invoices, can_delete_invoices, can_manage_documents, can_view_documents, can_upload_documents, can_delete_documents, can_view_reports, can_export_reports, can_manage_instructors, can_manage_settings, created_at, updated_at, updated_by, can_view_email_logs, can_edit_email_logs) FROM stdin;
2	8	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	f	2026-03-12 11:40:54.960683	2026-03-12 11:40:54.958361	3	t	f
1	7	f	f	f	f	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	t	2026-03-12 11:18:04.697338	2026-03-13 17:03:40.2354	3	t	f
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.alembic_version (version_num) FROM stdin;
add_grade_report_and_exp_letter
\.


--
-- Data for Name: attendance_requests; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.attendance_requests (id, student_id, course_id, schedule_id, requested_date, time_slot, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.attendances (id, student_id, course_id, instructor_id, date, time_slot, status, notes, created_at, updated_at) FROM stdin;
1	2	1	10	2026-03-24	14	PRESENT	hair	2026-03-24 00:48:39.974899	2026-03-24 06:43:27.855407
2	1	1	10	2026-03-24	14	REJECTED		2026-03-24 01:24:18.46127	2026-03-24 06:57:14.418989
3	1	1	10	2026-03-25	14	REJECTED	present	2026-03-24 07:52:58.523044	2026-03-24 07:55:00.000266
\.


--
-- Data for Name: certificate_templates; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.certificate_templates (id, name, html_content, css_styles, background_image_url, is_active, created_by, created_at, updated_at) FROM stdin;
3	womens heair dressing	<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE html>\n<html>\n<head>\n  <style>\n    .certificate {\n      width: 800px;\n      height: 600px;\n      padding: 40px;\n      text-align: center;\n      font-family: Arial, sans-serif;\n      border: 10px solid #1e40af;\n    }\n    .title {\n      font-size: 36px;\n      font-weight: bold;\n      color: #1e40af;\n      margin-bottom: 20px;\n    }\n    .subtitle {\n      font-size: 24px;\n      color: #4b5563;\n      margin-bottom: 40px;\n    }\n    .student-name {\n      font-size: 32px;\n      font-weight: bold;\n      color: #111827;\n      margin-bottom: 20px;\n    }\n    .course-name {\n      font-size: 24px;\n      color: #4b5563;\n      margin-bottom: 40px;\n    }\n    .date {\n      font-size: 16px;\n      color: #6b7280;\n    }\n    .certificate-number {\n      font-size: 12px;\n      color: #9ca3af;\n      margin-top: 20px;\n    }\n  </style>\n</head>\n<body>\n  <div class="certificate">\n    <div class="title">CERTIFICATE OF COMPLETION</div>\n    <div class="subtitle">This is to certify that</div>\n    <div class="student-name">{{student_name}}</div>\n    <div class="subtitle">has successfully completed the course</div>\n    <div class="course-name">{{course_name}}</div>\n    <div class="date">Issued on: {{issue_date}}</div>\n    <div class="certificate-number">Certificate No: {{certificate_number}}</div>\n  </div>\n</body>\n</html>	\N	\N	t	3	2026-03-08 12:25:15.403818	2026-03-08 12:25:15.403844
1	mens	<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>Certificate</title>\n    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Great+Vibes&family=Cormorant+Garamond:wght@400;500;600&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">\n    <style>\n        * {\n            margin: 0;\n            padding: 0;\n            box-sizing: border-box;\n        }\n\n        body {\n            margin: 0;\n            background: #f5f5f5;\n            display: flex;\n            justify-content: center;\n            align-items: center;\n            min-height: 100vh;\n            padding: 20px;\n        }\n\n        .certificate {\n            width: 1200px;\n            height: 850px;\n            max-width: 100%;\n            position: relative;\n            background: #FDFBF7;\n            border: 6px double #B8963A;\n            outline: 2px solid #C9A646;\n            outline-offset: -12px;\n            box-sizing: border-box;\n            overflow: visible;\n            page-break-inside: avoid;\n        }\n\n        .bg-image {\n            position: absolute;\n            top: 0;\n            left: 0;\n            width: 100%;\n            height: 100%;\n            object-fit: fill;\n            z-index: 0;\n        }\n\n        .content {\n            position: relative;\n            z-index: 1;\n            width: 100%;\n            height: 100%;\n            padding: 80px 100px 60px 100px;\n            display: flex;\n            flex-direction: column;\n        }\n\n        .header {\n            text-align: center;\n            margin-bottom: 20px;\n        }\n\n        .organization-name {\n            font-family: 'Playfair Display', serif;\n            font-weight: 700;\n            color: #C9A646;\n            font-size: 36px;\n            letter-spacing: 1.2px;\n        }\n\n        .sub-title {\n            font-family: 'Great Vibes', cursive;\n            font-weight: 400;\n            color: #2F5D50;\n            font-size: 32px;\n            margin-top: 5px;\n        }\n\n        .certificate-title {\n            font-family: 'Montserrat', sans-serif;\n            font-weight: 600;\n            color: #2F5D50;\n            font-size: 24px;\n            letter-spacing: 2.5px;\n            text-transform: uppercase;\n            margin-top: 30px;\n        }\n\n        .middle-section {\n            text-align: center;\n            flex: 1;\n            display: flex;\n            flex-direction: column;\n            justify-content: center;\n            margin: 25px;\n        }\n\n        .award-line {\n            font-family: 'Montserrat', sans-serif;\n            font-weight: 600;\n            color: #1F3A33;\n            font-size: 18px;\n            margin-bottom: 10px;\n        }\n\n        .recipient-name {\n            font-family: 'Playfair Display', serif;\n            font-weight: 700;\n            color: #C9A646;\n            font-size: 42px;\n            text-decoration: underline;\n            text-decoration-color: #C9A646;\n            text-decoration-thickness: 2px;\n        }\n\n        .body-text {\n            font-family: 'Cormorant Garamond', serif;\n            font-weight: 600;\n            color: #1A1A1A;\n            font-size: 20px;\n            text-align: center;\n            line-height: 1.5;\n            max-width: 800px;\n            margin: 0 auto;\n            padding: 0 30px;\n        }\n\n        .body-text strong {\n            color: #C9A646;\n            font-weight: 700;\n        }\n\n        .footer-section {\n            display: flex;\n            justify-content: space-between;\n            align-items: flex-end;\n            padding: 0 100px;\n        }\n\n        .footer-item {\n            text-align: center;\n        }\n\n        .footer-label {\n            font-family: 'Montserrat', sans-serif;\n            font-weight: 600;\n            color: #1F3A33;\n            font-size: 14px;\n            margin-bottom: 8px;\n        }\n\n        .footer-value {\n            font-family: 'Cormorant Garamond', serif;\n            font-weight: 500;\n            color: #1A1A1A;\n            font-size: 18px;\n            min-width: 180px;\n            border-bottom: 1px solid #1A1A1A;\n            padding-bottom: 5px;\n        }\n\n        .date-wrapper {\n            display: flex;\n            flex-direction: column;\n            align-items: center;\n        }\n\n        .date-wrapper .footer-label {\n            margin-top: 8px;\n        }\n\n        .signature-wrapper {\n            display: flex;\n            flex-direction: column;\n            align-items: center;\n        }\n\n        .stamp-line {\n            width: 100px;\n            height: auto;\n        }\n\n        .signature-line {\n            width: 180px;\n            border-bottom: 1px solid #1A1A1A;\n            margin: 5px 0;\n        }\n\n        .signature-img {\n            width: 120px;\n            height: auto;\n            display: block;\n            margin-top: -25px;\n        }\n\n        .director-name {\n            font-family: 'Montserrat', sans-serif;\n            font-weight: 600;\n            color: #1F3A33;\n            font-size: 12px;\n            margin-top: 3px;\n        }\n\n        .bottom-bar {\n            text-align: center;\n            margin-top: 12px;\n            position: relative;\n        }\n\n        .bottom-bar::before {\n            content: '';\n            position: absolute;\n            left: 50%;\n            transform: translateX(-50%);\n            width: 60%;\n            top: 0;\n            border-top: 2px solid #C9A646;\n        }\n\n        .bottom-bar-content {\n            display: flex;\n            justify-content: center;\n            gap: 40px;\n            padding-top: 10px;\n        }\n\n        .location {\n            font-family: 'Montserrat', sans-serif;\n            font-weight: 700;\n            color: #1F3A33;\n            font-size: 16px;\n        }\n\n        .phone {\n            font-family: 'Cormorant Garamond', serif;\n            font-weight: 600;\n            color: #6E6E6E;\n            font-size: 14px;\n        }\n\n        .photo-placeholder {\n            position: fixed;\n            left: 130px;\n            top: 240px;\n            width: 110px;\n            height: 110px;\n            border: 3px solid #C9A646;\n            display: flex;\n            align-items: center;\n            justify-content: center;\n            background: #FDFBF7;\n            z-index: 9999;\n            overflow: hidden;\n        }\n\n        .photo-placeholder img {\n            width: 100%;\n            height: 100%;\n            object-fit: cover;\n        }\n\n        .photo-placeholder .placeholder-text {\n            font-family: 'Montserrat', sans-serif;\n            font-size: 11px;\n            color: #6E6E6E;\n            text-align: center;\n            padding: 10px;\n        }\n\n        @media (max-width: 1200px) {\n            .certificate {\n                width: 100%;\n                height: auto;\n                aspect-ratio: 1200/850;\n            }\n        }\n\n        @media print {\n            @page {\n                size: A4 landscape;\n                margin: 0;\n            }\n            body {\n                background: white;\n                display: block;\n            }\n            .certificate {\n                width: 100%;\n                height: auto;\n                box-shadow: none;\n                print-color-adjust: exact;\n                -webkit-print-color-adjust: exact;\n            }\n            .bg-image {\n                print-color-adjust: exact;\n                -webkit-print-color-adjust: exact;\n            }\n        }\n    </style>\n</head>\n<body>\n\n<div class="certificate">\n    <img src="https://i.ibb.co/VpVzgYZc/background-design.png" class="bg-image" alt="">\n    \n    <div class="content">\n        <div class="header">\n            <div class="organization-name">Mulat Professional Beauty Training Center</div>\n            <div class="sub-title">Mulat Professional Hair Cutting Center</div>\n            <div class="certificate-title">CERTIFICATE OF {{ course_name }}</div>\n        </div>\n\n        <div class="middle-section">\n            <div class="award-line">THIS CERTIFICATE IS AWARDED TO</div>\n            <div class="recipient-name">{{ student_name }}</div>\n            <div class="body-text">\n                He has successfully completed a regular training program in the occupational area of hair cutting and salon ethics which qualify him/her to level 2 course from <strong>{{ issue_date }}</strong>.\n            </div>\n        </div>\n\n        <div class="footer-section">\n            <div class="footer-item date-wrapper">\n                <div class="footer-value">{{ issue_date }}</div>\n                <div class="footer-label">DATE</div>\n            </div>\n            <div class="footer-item signature-wrapper">\n                <img src="https://i.ibb.co/TVcRfcf/Screenshot-2026-04-02-212416-removebg-preview.png" class="stamp-line" alt="">\n                <div class="signature-line"></div>\n                <img src="https://i.ibb.co/FkVZz2sy/sig-1.png" class="signature-img" alt="">\n                <div class="director-name">DIRECTOR</div>\n            </div>\n        </div>\n\n        <div class="bottom-bar">\n            <div class="bottom-bar-content">\n                <div class="location">SHASHEMENE - ETHIOPIA</div>\n                <div class="phone">TEL: +251 916 82 24 46</div>\n                <div class="phone">{{ certificate_number }}</div>\n\n            </div>\n        </div>\n    </div>\n\n    <div class="photo-placeholder">\n        <img src="{{ student_photo_url }}" alt="Student Photo" onerror="this.style.display='none';this.nextElementSibling.style.display='block'">\n        <div class="placeholder-text" style="display:none">PHOTO</div>\n    </div>\n</div>\n\n</body>\n</html>\n	\N	0	t	3	2026-03-06 15:21:37.761285	2026-04-03 15:08:03.136809
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.certificates (id, certificate_number, student_id, template_id, course_id, issue_date, expiry_date, cert_metadata, pdf_url, status, revocation_reason, revoked_by, revoked_at, issued_by, created_at, updated_at) FROM stdin;
1	CERT-2026-127370	1	1	1	2026-03-06	2030-06-06	null	\N	REVOKED	payment not paid!	3	2026-03-06 21:52:59.73057	3	2026-03-06 21:14:54.29178	2026-03-06 21:52:59.730603
2	CERT-2026-305064	1	1	1	2026-03-06	2030-10-07	null	\N	REVOKED	payment not paid!	3	2026-03-06 22:03:01.003045	3	2026-03-06 21:53:40.916831	2026-03-06 22:03:01.003079
3	CERT-2026-219045	1	1	1	2026-03-06	2028-10-24	null	/uploads/certificates/2026/03/CERT-2026-219045.pdf	REVOKED	payment issue!	3	2026-03-06 22:23:53.469814	3	2026-03-06 22:04:27.155301	2026-03-06 22:23:53.46984
4	CERT-2026-100560	1	1	1	2026-03-06	2030-06-07	null	/uploads/certificates/2026/03/CERT-2026-100560.pdf	ACTIVE	\N	\N	\N	3	2026-03-06 22:30:18.028863	2026-03-06 22:30:18.028873
5	CERT-2026-149063	1	1	1	2026-03-06	2028-06-07	null	/uploads/certificates/2026/03/CERT-2026-149063.pdf	ACTIVE	\N	\N	\N	3	2026-03-06 22:38:52.795052	2026-03-06 22:38:52.795059
6	CERT-2026-310274	1	1	1	2026-03-06	2030-07-18	null	/uploads/certificates/2026/03/CERT-2026-310274.pdf	REVOKED	not selected!	3	2026-03-06 23:05:53.372436	3	2026-03-06 23:04:46.594905	2026-03-06 23:05:53.372446
7	CERT-2026-100761	1	1	1	2026-03-06	2042-10-07	null	/uploads/certificates/2026/03/CERT-2026-100761.pdf	ACTIVE	\N	\N	\N	3	2026-03-06 23:39:10.579889	2026-03-06 23:39:10.579896
8	CERT-2026-465053	1	1	1	2026-03-06	2094-10-07	null	/uploads/certificates/2026/03/CERT-2026-465053.pdf	ACTIVE	\N	\N	\N	3	2026-03-06 23:49:19.726069	2026-03-06 23:49:19.726079
9	CERT-2026-226113	1	1	1	2026-03-07	2121-01-01	null	/uploads/certificates/2026/03/CERT-2026-226113.pdf	ACTIVE	\N	\N	\N	3	2026-03-07 23:39:22.974775	2026-03-07 23:39:22.974797
10	CERT-2026-783941	1	1	1	2026-03-08	2237-05-08	null	/uploads/certificates/2026/03/CERT-2026-783941.pdf	ACTIVE	\N	\N	\N	3	2026-03-08 08:25:26.536611	2026-03-08 08:25:26.536616
11	CERT-2026-283668	1	1	1	2026-03-08	\N	null	/uploads/certificates/2026/03/CERT-2026-283668.pdf	ACTIVE	\N	\N	\N	3	2026-03-08 13:35:26.718095	2026-03-08 13:35:26.718099
12	CERT-2026-114340	1	1	1	2026-03-08	2222-01-08	null	/uploads/certificates/2026/03/CERT-2026-114340.pdf	REVOKED	no paid	3	2026-03-30 15:43:31.250812	3	2026-03-08 13:36:16.854837	2026-03-30 15:43:31.250869
13	CERT-2026-244585	1	1	1	2026-04-02	\N	null	/uploads/certificates/2026/04/CERT-2026-244585.pdf	REVOKED	no reason	3	2026-04-02 20:39:08.046097	3	2026-04-02 20:32:35.316168	2026-04-02 20:39:08.046132
14	CERT-2026-320410	1	1	1	2026-04-02	\N	null	/uploads/certificates/2026/04/CERT-2026-320410.pdf	REVOKED	stopped you\n	3	2026-04-02 20:42:40.187897	3	2026-04-02 20:39:21.490235	2026-04-02 20:42:40.187914
15	CERT-2026-369758	1	1	1	2026-04-02	\N	null	\N	REVOKED	nooo reason	3	2026-04-02 20:45:52.12833	3	2026-04-02 20:42:51.743821	2026-04-02 20:45:52.128342
16	CERT-2026-250840	1	1	1	2026-04-02	\N	null	\N	REVOKED	nooooo reason	3	2026-04-02 20:50:00.620487	3	2026-04-02 20:46:42.859709	2026-04-02 20:50:00.620505
17	CERT-2026-178060	1	1	1	2026-04-02	\N	null	/uploads/certificates/2026/04/CERT-2026-178060.pdf	REVOKED	noooooooooooooooo	3	2026-04-02 21:10:01.21041	3	2026-04-02 21:03:30.636833	2026-04-02 21:10:01.210436
18	CERT-2026-406902	1	1	1	2026-04-03	\N	null	/uploads/certificates/2026/04/CERT-2026-406902.pdf	REVOKED	ggggggggggggggggggggg	3	2026-04-02 21:20:14.384303	3	2026-04-02 21:14:11.665769	2026-04-02 21:20:14.384337
19	CERT-2026-132839	1	1	1	2026-04-02	\N	null	/uploads/certificates/2026/04/CERT-2026-132839.pdf	ACTIVE	\N	\N	\N	3	2026-04-02 21:20:30.855801	2026-04-02 21:20:30.855815
20	CERT-2026-176473	1	1	1	2026-04-30	\N	null	/uploads/certificates/2026/04/CERT-2026-176473.pdf	REVOKED	noooooooooooo	3	2026-04-03 14:31:01.654817	3	2026-04-03 13:59:40.453783	2026-04-03 14:31:01.654827
21	CERT-2026-613341	1	1	1	2026-04-03	\N	null	/uploads/certificates/2026/04/CERT-2026-613341.pdf	REVOKED	nooooo	3	2026-04-03 14:31:07.75136	3	2026-04-03 14:27:09.766889	2026-04-03 14:31:07.751377
22	CERT-2026-215260	1	1	1	2026-04-03	\N	null	/uploads/certificates/2026/04/CERT-2026-215260.pdf	REVOKED	noooooooooooo	3	2026-04-03 14:34:11.913791	3	2026-04-03 14:31:18.132276	2026-04-03 14:34:11.913806
23	CERT-2026-329465	1	1	1	2026-04-10	\N	null	/uploads/certificates/2026/04/CERT-2026-329465.pdf	REVOKED	noooooooooooo	3	2026-04-03 14:36:44.423411	3	2026-04-03 14:34:30.552956	2026-04-03 14:36:44.42343
24	CERT-2026-368253	1	1	1	2026-04-16	\N	null	/uploads/certificates/2026/04/CERT-2026-368253.pdf	REVOKED	nnooooo	3	2026-04-03 14:40:41.578748	3	2026-04-03 14:36:58.935708	2026-04-03 14:40:41.578757
26	CERT-2026-205951	1	1	1	2026-04-03	\N	null	/uploads/certificates/2026/04/CERT-2026-205951.pdf	REVOKED	nooooooooo	3	2026-04-03 14:45:42.267513	3	2026-04-03 14:42:56.132436	2026-04-03 14:45:42.26753
25	CERT-2026-217680	1	1	1	2026-04-03	\N	null	/uploads/certificates/2026/04/CERT-2026-217680.pdf	REVOKED	nooooo	3	2026-04-03 14:45:49.62756	3	2026-04-03 14:40:56.122177	2026-04-03 14:45:49.627572
27	CERT-2026-143446	1	1	1	2026-04-03	\N	null	/uploads/certificates/2026/04/CERT-2026-143446.pdf	REVOKED	noooooooo	3	2026-04-03 14:48:18.676614	3	2026-04-03 14:46:02.055655	2026-04-03 14:48:18.676623
28	CERT-2026-755827	1	1	1	2026-04-29	\N	null	/uploads/certificates/2026/04/CERT-2026-755827.pdf	REVOKED	noooooo	3	2026-04-03 15:02:02.359403	3	2026-04-03 14:48:29.915416	2026-04-03 15:02:02.359409
29	CERT-2026-304156	1	1	1	2026-04-03	\N	null	/uploads/certificates/2026/04/CERT-2026-304156.pdf	REVOKED	nooooo	3	2026-04-03 15:05:53.92877	3	2026-04-03 15:02:27.388465	2026-04-03 15:05:53.928776
30	CERT-2026-358509	1	1	1	2026-04-15	\N	null	/uploads/certificates/2026/04/CERT-2026-358509.pdf	REVOKED	noooooo	3	2026-04-03 15:12:32.795567	3	2026-04-03 15:06:23.704402	2026-04-03 15:12:32.795574
31	CERT-2026-253993	1	1	1	2026-04-08	\N	null	/uploads/certificates/2026/04/CERT-2026-253993.pdf	REVOKED	nooooo	3	2026-04-04 14:50:39.65418	3	2026-04-03 15:13:21.908396	2026-04-04 14:50:39.654199
32	CERT-2026-420862	1	1	1	2026-04-15	\N	null	/uploads/certificates/2026/04/CERT-2026-420862.pdf	ACTIVE	\N	\N	\N	3	2026-04-04 14:52:38.731879	2026-04-04 14:52:38.731888
33	CERT-2026-637428	2	1	1	2026-04-04	\N	null	/uploads/certificates/2026/04/CERT-2026-637428.pdf	ACTIVE	\N	\N	\N	3	2026-04-04 15:07:10.773492	2026-04-04 15:07:10.773498
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.courses (id, name, description, duration_hours, duration_text, level, is_active, created_at, updated_at) FROM stdin;
1	Men's Barber	mens barber	40.00	3 month	intermediate	t	2026-03-06 12:39:38.448978	2026-03-06 12:40:11.419542
2	womens herdressing	3 month course	\N	3 month	intermediate	t	2026-03-08 12:31:37.511399	2026-03-29 19:22:40.827346
3	makeup	\N	\N	\N	intermediate	t	2026-03-08 19:31:19.258542	2026-03-29 19:54:59.081377
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.email_logs (id, recipient_email, subject, email_type, template_name, body_text, body_html, context_data, related_user_id, related_entity_type, related_entity_id, status, error_message, retry_count, last_retry_at, created_at, sent_at) FROM stdin;
1	ermiasmesfinabebe@gmail.com	Enrollment Confirmed - Men's Barber	enrollment_confirmation	enrollment_confirmation	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nEnrollment Confirmed! 🎉\n\n    Congratulations Student!\n\n    Your enrollment has been confirmed. We're excited to have you join us for Men&#39;s Barber!\n\n            ✅ ENROLLMENT DETAILS\n            Course: Men&#39;s Barber\n            Enrollment ID: #29\n            Status: Active\n\nWhat's Next?\n\n            📚\n            Access Course Materials\n\n            Log in to your student portal to view all course content\n\n            📅\n            Check Schedule\n\n            View upcoming classes and attendance schedule\n\n            💬\n            Connect with Instructors\n\n            Use the chat feature to ask questions\n\n                Go to My Courses →\n\n    Questions?\n\n    Contact our support team at support@yminternationalbeautyacademy.com\n\n    Best wishes for your learning journey!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Addis Ababa, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Enrollment Confirmed! 🎉</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Congratulations Student!\n</p>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Your enrollment has been confirmed. We're excited to have you join us for <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ ENROLLMENT DETAILS</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Course:</strong> Men&#39;s Barber</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Enrollment ID:</strong> #29</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Status:</strong> Active</p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">What's Next?</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📚</span>\n            <strong style="color: #004080;">Access Course Materials</strong><br>\n            <span style="color: #666666; font-size: 13px;">Log in to your student portal to view all course content</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📅</span>\n            <strong style="color: #004080;">Check Schedule</strong><br>\n            <span style="color: #666666; font-size: 13px;">View upcoming classes and attendance schedule</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0;">\n            <span style="font-size: 20px; margin-right: 10px;">💬</span>\n            <strong style="color: #004080;">Connect with Instructors</strong><br>\n            <span style="color: #666666; font-size: 13px;">Use the chat feature to ask questions</span>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/courses" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                Go to My Courses →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<p style="margin: 0; color: #004080; font-size: 14px;">\n    <strong>Questions?</strong><br>\n    Contact our support team at <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080;">support@yminternationalbeautyacademy.com</a>\n</p>\n\n<p style="margin: 20px 0 0 0; color: #555555; font-size: 14px;">\n    Best wishes for your learning journey!<br>\n    <strong style="color: #004080;">The YM Beauty Academy Team 💜</strong>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Addis Ababa, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "Student", "course_name": "Men's Barber", "enrollment_id": 29, "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	enrollment	29	debug	\N	0	\N	2026-03-30 17:17:40.923323	\N
2	ermiasmesfinabebe@gmail.com	Enrollment Confirmed - womens herdressing	enrollment_confirmation	enrollment_confirmation	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nEnrollment Confirmed! 🎉\n\n    Congratulations Student!\n\n    Your enrollment has been confirmed. We're excited to have you join us for womens herdressing!\n\n            ✅ ENROLLMENT DETAILS\n            Course: womens herdressing\n            Enrollment ID: #30\n            Status: Active\n\nWhat's Next?\n\n            📚\n            Access Course Materials\n\n            Log in to your student portal to view all course content\n\n            📅\n            Check Schedule\n\n            View upcoming classes and attendance schedule\n\n            💬\n            Connect with Instructors\n\n            Use the chat feature to ask questions\n\n                Go to My Courses →\n\n    Questions?\n\n    Contact our support team at support@yminternationalbeautyacademy.com\n\n    Best wishes for your learning journey!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Addis Ababa, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Enrollment Confirmed! 🎉</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Congratulations Student!\n</p>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Your enrollment has been confirmed. We're excited to have you join us for <strong style="color: #004080;">womens herdressing</strong>!\n</p>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ ENROLLMENT DETAILS</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Course:</strong> womens herdressing</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Enrollment ID:</strong> #30</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Status:</strong> Active</p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">What's Next?</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📚</span>\n            <strong style="color: #004080;">Access Course Materials</strong><br>\n            <span style="color: #666666; font-size: 13px;">Log in to your student portal to view all course content</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📅</span>\n            <strong style="color: #004080;">Check Schedule</strong><br>\n            <span style="color: #666666; font-size: 13px;">View upcoming classes and attendance schedule</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0;">\n            <span style="font-size: 20px; margin-right: 10px;">💬</span>\n            <strong style="color: #004080;">Connect with Instructors</strong><br>\n            <span style="color: #666666; font-size: 13px;">Use the chat feature to ask questions</span>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/courses" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                Go to My Courses →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<p style="margin: 0; color: #004080; font-size: 14px;">\n    <strong>Questions?</strong><br>\n    Contact our support team at <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080;">support@yminternationalbeautyacademy.com</a>\n</p>\n\n<p style="margin: 20px 0 0 0; color: #555555; font-size: 14px;">\n    Best wishes for your learning journey!<br>\n    <strong style="color: #004080;">The YM Beauty Academy Team 💜</strong>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Addis Ababa, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "Student", "course_name": "womens herdressing", "enrollment_id": 30, "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	enrollment	30	sent	\N	0	\N	2026-03-30 17:34:43.022072	2026-03-30 17:35:06.035132
3	ermiasmesfinabebe@gmail.com	Enrollment Confirmed - makeup	enrollment_confirmation	enrollment_confirmation	Enrollment Confirmed! 🎉\n\nCongratulations dawit!\n\nYour enrollment has been confirmed. We're excited to have you join us for makeup!\n\nENROLLMENT DETAILS\nCourse: makeup\nEnrollment ID: #31\nStatus: Active\n\nWhat's Next?\n\n- Access Course Materials: Log in to your student portal to view all course content\n- Check Schedule: View upcoming classes and attendance schedule\n- Connect with Instructors: Use the chat feature to ask questions\n\nNeed Assistance?\nIf you have any questions, our support team is here to help. Simply reply to this email or contact us through your student portal.\n\nWelcome aboard!\nYM Beauty Academy Team	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Enrollment Confirmed! 🎉</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Congratulations dawit!\n</p>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Your enrollment has been confirmed. We're excited to have you join us for <strong style="color: #004080;">makeup</strong>!\n</p>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ ENROLLMENT DETAILS</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Course:</strong> makeup</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Enrollment ID:</strong> #31</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Status:</strong> Active</p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">What's Next?</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📚</span>\n            <strong style="color: #004080;">Access Course Materials</strong><br>\n            <span style="color: #666666; font-size: 13px;">Log in to your student portal to view all course content</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📅</span>\n            <strong style="color: #004080;">Check Schedule</strong><br>\n            <span style="color: #666666; font-size: 13px;">View upcoming classes and attendance schedule</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0;">\n            <span style="font-size: 20px; margin-right: 10px;">💬</span>\n            <strong style="color: #004080;">Connect with Instructors</strong><br>\n            <span style="color: #666666; font-size: 13px;">Use the chat feature to ask questions</span>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/courses" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                Go to My Courses →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<p style="margin: 0; color: #004080; font-size: 14px;">\n    <strong>Questions?</strong><br>\n    Contact our support team at <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080;">support@yminternationalbeautyacademy.com</a>\n</p>\n\n<p style="margin: 20px 0 0 0; color: #555555; font-size: 14px;">\n    Best wishes for your learning journey!<br>\n    <strong style="color: #004080;">The YM Beauty Academy Team 💜</strong>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Addis Ababa, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "course_name": "makeup", "enrollment_id": 31, "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	enrollment	31	sent	\N	0	\N	2026-03-30 18:30:47.995553	2026-03-30 18:30:50.998215
4	ermiasmesfinabebe@gmail.com	New Invoice - INV-2026-CACEAD	invoice_sent	invoice_sent	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nNew Invoice 📄\n\n    Dear dawit,\n\n    A new invoice has been generated for your enrollment at YM Beauty Academy. Please review the details below.\n\n                        YM International Beauty Academy\n                        Addis Ababa, Ethiopia\n\n                        INVOICE\n                        #INV-2026-CACEAD\n\n                    Issue Date:\n                    March 31, 2026\n\n                    Due Date:\n                    N/A\n\n                    Course:\n                    Men&#39;s Barber\n\n                    AMOUNT DUE\n                    2,000.00\n\n                ⚠️ Payment Required - Please make your payment by N/A to avoid any interruption to your studies.\n\n                View Invoice Details →\n\n    If you have any questions about this invoice or need to discuss payment options, please contact our finance team.\n\n    finance@yminternationalbeautyacademy.com\n\n    Thank you for choosing YM Beauty Academy!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">New Invoice 📄</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Dear dawit,\n</p>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    A new invoice has been generated for your enrollment at YM Beauty Academy. Please review the details below.\n</p>\n\n<!-- Invoice Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f8f9fa; border-radius: 8px; margin: 25px 0;">\n    <tr>\n        <td style="padding: 25px;">\n            <!-- Header -->\n            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-bottom: 2px solid #004080; padding-bottom: 15px; margin-bottom: 15px;">\n                <tr>\n                    <td>\n                        <p style="margin: 0; color: #004080; font-weight: 700; font-size: 18px;">YM International Beauty Academy</p>\n                        <p style="margin: 5px 0 0 0; color: #666666; font-size: 12px;">Addis Ababa, Ethiopia</p>\n                    </td>\n                    <td align="right">\n                        <p style="margin: 0; color: #666666; font-size: 12px;">INVOICE</p>\n                        <p style="margin: 5px 0 0 0; color: #004080; font-weight: 600; font-size: 14px;">#INV-2026-CACEAD</p>\n                    </td>\n                </tr>\n            </table>\n            \n            <!-- Details -->\n            <table role="presentation" width="100%" cellspacing="0" cellpadding="0">\n                <tr>\n                    <td style="padding: 8px 0; color: #666666; font-size: 13px;">Issue Date:</td>\n                    <td style="padding: 8px 0; color: #333333; font-size: 13px; text-align: right;">March 31, 2026</td>\n                </tr>\n                <tr>\n                    <td style="padding: 8px 0; color: #666666; font-size: 13px;">Due Date:</td>\n                    <td style="padding: 8px 0; color: #333333; font-size: 13px; text-align: right;">N/A</td>\n                </tr>\n                <tr>\n                    <td style="padding: 8px 0; color: #666666; font-size: 13px;">Course:</td>\n                    <td style="padding: 8px 0; color: #333333; font-size: 13px; text-align: right;">Men&#39;s Barber</td>\n                </tr>\n            </table>\n            \n            <!-- Divider -->\n            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 15px 0;">\n                <tr>\n                    <td style="border-top: 1px dashed #cccccc;"></td>\n                </tr>\n            </table>\n            \n            <!-- Amount Due -->\n            <table role="presentation" width="100%" cellspacing="0" cellpadding="0">\n                <tr>\n                    <td style="padding: 10px 0; color: #004080; font-weight: 600; font-size: 15px;">AMOUNT DUE</td>\n                    <td style="padding: 10px 0; color: #dc3545; font-weight: 700; font-size: 20px; text-align: right;">2,000.00</td>\n                </tr>\n            </table>\n        </td>\n    </tr>\n</table>\n\n<!-- Payment Reminder -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #fff3cd; border-left: 4px solid #ffc107; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 15px 20px;">\n            <p style="margin: 0; color: #856404; font-size: 14px;">\n                ⚠️ <strong>Payment Required</strong> - Please make your payment by N/A to avoid any interruption to your studies.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/invoices" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View Invoice Details →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<p style="margin: 0; color: #555555; font-size: 13px; line-height: 1.7;">\n    If you have any questions about this invoice or need to discuss payment options, please contact our finance team.<br>\n    <a href="mailto:finance@yminternationalbeautyacademy.com" style="color: #004080;">finance@yminternationalbeautyacademy.com</a>\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Thank you for choosing YM Beauty Academy!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "invoice_number": "INV-2026-CACEAD", "issue_date": "March 31, 2026", "due_date": "N/A", "course_name": "Men's Barber", "grand_total": "2,000.00", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	invoice	29	sent	\N	0	\N	2026-03-31 08:41:15.735027	2026-03-31 08:41:19.989215
5	ermiasmesfinabebe@gmail.com	Enrollment Confirmed - Men's Barber	enrollment_confirmation	enrollment_confirmation	Enrollment Confirmed! 🎉\n\nCongratulations dawit!\n\nYour enrollment has been confirmed. We're excited to have you join us for Men's Barber!\n\nENROLLMENT DETAILS\nCourse: Men's Barber\nEnrollment ID: #32\nStatus: Active\n\nWhat's Next?\n\n- Access Course Materials: Log in to your student portal to view all course content\n- Check Schedule: View upcoming classes and attendance schedule\n- Connect with Instructors: Use the chat feature to ask questions\n\nNeed Assistance?\nIf you have any questions, our support team is here to help. Simply reply to this email or contact us through your student portal.\n\nWelcome aboard!\nYM Beauty Academy Team	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Enrollment Confirmed! 🎉</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Congratulations dawit!\n</p>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Your enrollment has been confirmed. We're excited to have you join us for <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ ENROLLMENT DETAILS</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Course:</strong> Men&#39;s Barber</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Enrollment ID:</strong> #32</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Status:</strong> Active</p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">What's Next?</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📚</span>\n            <strong style="color: #004080;">Access Course Materials</strong><br>\n            <span style="color: #666666; font-size: 13px;">Log in to your student portal to view all course content</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📅</span>\n            <strong style="color: #004080;">Check Schedule</strong><br>\n            <span style="color: #666666; font-size: 13px;">View upcoming classes and attendance schedule</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0;">\n            <span style="font-size: 20px; margin-right: 10px;">💬</span>\n            <strong style="color: #004080;">Connect with Instructors</strong><br>\n            <span style="color: #666666; font-size: 13px;">Use the chat feature to ask questions</span>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/courses" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                Go to My Courses →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<p style="margin: 0; color: #004080; font-size: 14px;">\n    <strong>Questions?</strong><br>\n    Contact our support team at <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080;">support@yminternationalbeautyacademy.com</a>\n</p>\n\n<p style="margin: 20px 0 0 0; color: #555555; font-size: 14px;">\n    Best wishes for your learning journey!<br>\n    <strong style="color: #004080;">The YM Beauty Academy Team 💜</strong>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "course_name": "Men's Barber", "enrollment_id": 32, "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	enrollment	32	sent	\N	0	\N	2026-03-31 08:41:20.335196	2026-03-31 08:41:23.575251
6	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 02, 2026\n            Certificate #: CERT-2026-244585\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 02, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-244585</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-244585", "course_name": "Men's Barber", "issue_date": "April 02, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	13	sent	\N	0	\N	2026-04-02 20:32:35.397952	2026-04-02 20:32:45.490534
7	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 02, 2026\n            Certificate #: CERT-2026-320410\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 02, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-320410</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-320410", "course_name": "Men's Barber", "issue_date": "April 02, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	14	sent	\N	0	\N	2026-04-02 20:39:21.620216	2026-04-02 20:39:27.910013
8	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 02, 2026\n            Certificate #: CERT-2026-369758\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 02, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-369758</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-369758", "course_name": "Men's Barber", "issue_date": "April 02, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	15	sent	\N	0	\N	2026-04-02 20:42:51.949622	2026-04-02 20:43:10.421651
9	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 02, 2026\n            Certificate #: CERT-2026-250840\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 02, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-250840</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-250840", "course_name": "Men's Barber", "issue_date": "April 02, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	16	sent	\N	0	\N	2026-04-02 20:46:42.917502	2026-04-02 20:46:59.594857
10	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 02, 2026\n            Certificate #: CERT-2026-178060\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 02, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-178060</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-178060", "course_name": "Men's Barber", "issue_date": "April 02, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	17	sent	\N	0	\N	2026-04-02 21:03:30.904352	2026-04-02 21:03:35.800752
11	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 02, 2026\n            Certificate #: CERT-2026-406902\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 02, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-406902</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-406902", "course_name": "Men's Barber", "issue_date": "April 02, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	18	sent	\N	0	\N	2026-04-02 21:14:11.773942	2026-04-02 21:14:43.03097
12	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 02, 2026\n            Certificate #: CERT-2026-132839\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 02, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-132839</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-132839", "course_name": "Men's Barber", "issue_date": "April 02, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	19	sent	\N	0	\N	2026-04-02 21:20:30.930883	2026-04-02 21:20:36.135913
13	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-176473\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-176473</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-176473", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	20	sent	\N	0	\N	2026-04-03 13:59:40.518545	2026-04-03 13:59:44.604739
14	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-613341\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-613341</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-613341", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	21	sent	\N	0	\N	2026-04-03 14:27:09.824101	2026-04-03 14:27:15.105005
15	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-215260\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-215260</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-215260", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	22	sent	\N	0	\N	2026-04-03 14:31:18.183307	2026-04-03 14:31:23.654563
16	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-329465\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-329465</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-329465", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	23	sent	\N	0	\N	2026-04-03 14:34:30.605687	2026-04-03 14:34:34.754475
17	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-368253\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-368253</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-368253", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	24	sent	\N	0	\N	2026-04-03 14:36:58.989473	2026-04-03 14:37:02.790556
18	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-217680\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-217680</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-217680", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	25	sent	\N	0	\N	2026-04-03 14:40:56.179567	2026-04-03 14:41:00.769098
19	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-205951\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-205951</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-205951", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	26	sent	\N	0	\N	2026-04-03 14:42:56.157095	2026-04-03 14:43:00.058899
20	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-143446\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-143446</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-143446", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	27	sent	\N	0	\N	2026-04-03 14:46:02.113511	2026-04-03 14:46:06.137818
21	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-755827\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-755827</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-755827", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	28	sent	\N	0	\N	2026-04-03 14:48:29.976908	2026-04-03 14:48:35.127749
22	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-304156\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-304156</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-304156", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	29	sent	\N	0	\N	2026-04-03 15:02:27.42003	2026-04-03 15:02:36.732884
23	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-358509\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-358509</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-358509", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	30	sent	\N	0	\N	2026-04-03 15:06:23.73391	2026-04-03 15:06:33.571599
24	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 03, 2026\n            Certificate #: CERT-2026-253993\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 03, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-253993</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-253993", "course_name": "Men's Barber", "issue_date": "April 03, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	31	sent	\N	0	\N	2026-04-03 15:13:21.931973	2026-04-03 15:13:28.820741
25	ermiasmesfinabebe@gmail.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, dawit! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 04, 2026\n            Certificate #: CERT-2026-420862\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, dawit! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 04, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-420862</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "dawit", "certificate_number": "CERT-2026-420862", "course_name": "Men's Barber", "issue_date": "April 04, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	4	certificate	32	sent	\N	0	\N	2026-04-04 14:52:38.768801	2026-04-04 14:52:49.491586
26	selam@mulat.com	Enrollment Confirmed - Men's Barber	enrollment_confirmation	enrollment_confirmation	Enrollment Confirmed! 🎉\n\nCongratulations selam!\n\nYour enrollment has been confirmed. We're excited to have you join us for Men's Barber!\n\nENROLLMENT DETAILS\nCourse: Men's Barber\nEnrollment ID: #33\nStatus: Active\n\nWhat's Next?\n\n- Access Course Materials: Log in to your student portal to view all course content\n- Check Schedule: View upcoming classes and attendance schedule\n- Connect with Instructors: Use the chat feature to ask questions\n\nNeed Assistance?\nIf you have any questions, our support team is here to help. Simply reply to this email or contact us through your student portal.\n\nWelcome aboard!\nYM Beauty Academy Team	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Enrollment Confirmed! 🎉</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Congratulations selam!\n</p>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    Your enrollment has been confirmed. We're excited to have you join us for <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ ENROLLMENT DETAILS</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Course:</strong> Men&#39;s Barber</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Enrollment ID:</strong> #33</p>\n            <p style="margin: 5px 0; color: #333333; font-size: 14px;"><strong>Status:</strong> Active</p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">What's Next?</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📚</span>\n            <strong style="color: #004080;">Access Course Materials</strong><br>\n            <span style="color: #666666; font-size: 13px;">Log in to your student portal to view all course content</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee;">\n            <span style="font-size: 20px; margin-right: 10px;">📅</span>\n            <strong style="color: #004080;">Check Schedule</strong><br>\n            <span style="color: #666666; font-size: 13px;">View upcoming classes and attendance schedule</span>\n        </td>\n    </tr>\n    <tr>\n        <td style="padding: 12px 0;">\n            <span style="font-size: 20px; margin-right: 10px;">💬</span>\n            <strong style="color: #004080;">Connect with Instructors</strong><br>\n            <span style="color: #666666; font-size: 13px;">Use the chat feature to ask questions</span>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/courses" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                Go to My Courses →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<p style="margin: 0; color: #004080; font-size: 14px;">\n    <strong>Questions?</strong><br>\n    Contact our support team at <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080;">support@yminternationalbeautyacademy.com</a>\n</p>\n\n<p style="margin: 20px 0 0 0; color: #555555; font-size: 14px;">\n    Best wishes for your learning journey!<br>\n    <strong style="color: #004080;">The YM Beauty Academy Team 💜</strong>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "selam", "course_name": "Men's Barber", "enrollment_id": 33, "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	5	enrollment	33	sent	\N	0	\N	2026-04-04 15:05:40.05295	2026-04-04 15:05:43.949821
27	selam@mulat.com	Congratulations! Certificate Issued - Men's Barber	certificate_issued	certificate_issued	YM International Beauty Academy\n\n                            YM International Beauty Academy\n                            Your Journey to Beauty Excellence Starts Here\n\nCongratulations, selam! 🏆\n\n    We are thrilled to announce that you have successfully completed Men&#39;s Barber!\n\n            🎓\n            CERTIFICATE OF COMPLETION\n            Men&#39;s Barber\n            Issued on April 04, 2026\n            Certificate #: CERT-2026-637428\n\n            ✅ YOUR ACHIEVEMENT\n\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n\nShare Your Achievement!\n\n            Share your certificate on LinkedIn or add it to your resume to showcase your skills!\n\n                View My Certificates →\n\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n\n    What's Next?\n\n    Browse our other courses and continue your professional development!\n\n    Congratulations once again!\n\n    The YM Beauty Academy Team 💜\n\n                            YM International Beauty Academy\n\n                                Shashemene, Oromia, Ethiopia\n\n                                support@yminternationalbeautyacademy.com\n\n                                    Website\n                                    |\n                                    Courses\n                                    |\n                                    Contact\n\n                                © 2026 YM International Beauty Academy. All rights reserved.\n\n                                You received this email because you have an account with us.	<!DOCTYPE html>\n<html>\n<head>\n    <meta charset="utf-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>YM International Beauty Academy</title>\n</head>\n<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">\n    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4;">\n        <tr>\n            <td align="center" style="padding: 40px 10px;">\n                <!-- Email Container -->\n                <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 64, 128, 0.1);">\n                    \n                    <!-- Header with Logo -->\n                    <tr>\n                        <td style="background: linear-gradient(135deg, #004080 0%, #003366 100%); padding: 40px 30px; text-align: center;">\n                            <img src="https://yminternationalbeautyacademy.com/images/logo.png" alt="YM International Beauty Academy" height="60" style="height: 60px; margin-bottom: 15px;">\n                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: 0.5px;">YM International Beauty Academy</h1>\n                            <p style="margin: 10px 0 0 0; color: #ffd700; font-size: 14px;">Your Journey to Beauty Excellence Starts Here</p>\n                        </td>\n                    </tr>\n                    \n                    <!-- Email Content -->\n                    <tr>\n                        <td style="padding: 40px 35px;">\n                            \n<h2 style="margin: 0 0 20px 0; color: #004080; font-size: 22px;">Congratulations, selam! 🏆</h2>\n\n<p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.7;">\n    We are thrilled to announce that you have successfully completed <strong style="color: #004080;">Men&#39;s Barber</strong>!\n</p>\n\n<!-- Certificate Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background: linear-gradient(135deg, #004080 0%, #003366 100%); border-radius: 12px; margin: 25px 0; text-align: center;">\n    <tr>\n        <td style="padding: 35px 25px;">\n            <p style="margin: 0 0 15px 0; color: #ffd700; font-size: 48px;">🎓</p>\n            <p style="margin: 0 0 10px 0; color: #ffffff; font-size: 18px; font-weight: 600;">CERTIFICATE OF COMPLETION</p>\n            <p style="margin: 0 0 5px 0; color: #ffd700; font-size: 14px;">Men&#39;s Barber</p>\n            <p style="margin: 15px 0 0 0; color: #ffffff; font-size: 13px; opacity: 0.9;">Issued on April 04, 2026</p>\n            <p style="margin: 5px 0 0 0; color: #ffd700; font-size: 12px;">Certificate #: CERT-2026-637428</p>\n        </td>\n    </tr>\n</table>\n\n<!-- Success Box -->\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #d4edda; border-left: 4px solid #28a745; border-radius: 0 8px 8px 0; margin: 25px 0;">\n    <tr>\n        <td style="padding: 20px;">\n            <p style="margin: 0 0 10px 0; color: #155724; font-weight: 600; font-size: 14px;">✅ YOUR ACHIEVEMENT</p>\n            <p style="margin: 0; color: #333333; font-size: 14px; line-height: 1.7;">\n                Your certificate is now available in your student portal. You can download, share, or print it at any time.\n            </p>\n        </td>\n    </tr>\n</table>\n\n<h3 style="margin: 30px 0 15px 0; color: #004080; font-size: 16px;">Share Your Achievement!</h3>\n\n<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 0 0 25px 0;">\n    <tr>\n        <td style="padding: 10px 15px; background-color: #f8f9fa; border-radius: 8px; text-align: center;">\n            <p style="margin: 0 0 10px 0; color: #666666; font-size: 13px;">Share your certificate on LinkedIn or add it to your resume to showcase your skills!</p>\n        </td>\n    </tr>\n</table>\n\n<!-- CTA Button -->\n<table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 30px 0;">\n    <tr>\n        <td style="border-radius: 25px; background: linear-gradient(135deg, #004080 0%, #003366 100%); text-align: center;">\n            <a href="https://yminternationalbeautyacademy.com/student/certificates" style="display: inline-block; padding: 14px 40px; color: #ffffff; text-decoration: none; font-weight: 600; font-size: 15px;">\n                View My Certificates →\n            </a>\n        </td>\n    </tr>\n</table>\n\n<hr style="border: none; border-top: 1px solid #eeeeee; margin: 25px 0;">\n\n<p style="margin: 0 0 20px 0; color: #555555; font-size: 14px; line-height: 1.7;">\n    We are incredibly proud of your accomplishment! Completing a professional course takes dedication and hard work. \n    This certificate is a testament to your commitment to excellence.\n</p>\n\n<p style="margin: 0; color: #555555; font-size: 14px;">\n    <strong style="color: #004080;\\">What's Next?</strong><br>\n    Browse our other courses and continue your professional development!\n</p>\n\n<p style="margin: 20px 0 0 0; color: #004080; font-size: 14px;">\n    <strong>Congratulations once again!</strong><br>\n    <span style="color: #555555;">The YM Beauty Academy Team 💜</span>\n</p>\n\n                        </td>\n                    </tr>\n                    \n                    <!-- Footer -->\n                    <tr>\n                        <td style="background-color: #f8f9fa; padding: 30px; text-align: center; border-top: 3px solid #ffd700;">\n                            <p style="margin: 0 0 10px 0; color: #004080; font-weight: 600; font-size: 14px;">YM International Beauty Academy</p>\n                            <p style="margin: 0 0 15px 0; color: #666666; font-size: 12px;">\n                                Shashemene, Oromia, Ethiopia<br>\n                                <a href="mailto:support@yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none;">support@yminternationalbeautyacademy.com</a>\n                            </p>\n                            <table role="presentation" align="center" cellspacing="0" cellpadding="0" style="margin: 15px auto;">\n                                <tr>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com" style="color: #004080; text-decoration: none; font-size: 12px;">Website</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/courses" style="color: #004080; text-decoration: none; font-size: 12px;">Courses</a></td>\n                                    <td style="color: #dddddd;">|</td>\n                                    <td style="padding: 0 8px;"><a href="https://yminternationalbeautyacademy.com/contact" style="color: #004080; text-decoration: none; font-size: 12px;">Contact</a></td>\n                                </tr>\n                            </table>\n                            <p style="margin: 20px 0 0 0; color: #999999; font-size: 11px;">\n                                © 2026 YM International Beauty Academy. All rights reserved.<br>\n                                You received this email because you have an account with us.\n                            </p>\n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n    </table>\n</body>\n</html>	{"first_name": "selam", "certificate_number": "CERT-2026-637428", "course_name": "Men's Barber", "issue_date": "April 04, 2026", "base_url": "https://yminternationalbeautyacademy.com", "year": 2026}	5	certificate	33	sent	\N	0	\N	2026-04-04 15:07:10.850987	2026-04-04 15:07:19.599322
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.enrollments (id, student_id, course_id, status, enrolled_at, start_date, completion_date, grade, attendance_percentage, notes, created_at, updated_at, fee) FROM stdin;
32	1	1	COMPLETED	2026-03-31 08:41:14.819319	2026-03-31	2026-06-16	\N	\N	\N	2026-03-31 08:41:14.819349	2026-04-02 20:23:53.281991	2000.00
33	2	1	COMPLETED	2026-04-04 15:05:39.948281	2026-04-13	2026-07-14	\N	\N	\N	2026-04-04 15:05:39.948287	2026-04-04 15:05:39.948289	5000.00
\.


--
-- Data for Name: instructor_courses; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.instructor_courses (id, instructor_id, course_id, assigned_by, assigned_at, is_active) FROM stdin;
1	10	1	3	2026-03-23 13:47:19.945432	t
\.


--
-- Data for Name: instructor_schedules; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.instructor_schedules (id, instructor_id, course_id, date, start_time, end_time, notes, is_active, created_at, updated_at) FROM stdin;
1	10	\N	2026-03-23	9	12		t	2026-03-23 19:59:09.14004	2026-03-23 19:59:09.140046
2	10	\N	2026-03-24	9	12		t	2026-03-23 19:59:09.140049	2026-03-23 19:59:09.14005
3	10	\N	2026-03-25	9	12		t	2026-03-23 19:59:09.140052	2026-03-23 19:59:09.140053
4	10	\N	2026-03-26	9	12		t	2026-03-23 19:59:09.140055	2026-03-23 19:59:09.140056
5	10	\N	2026-03-27	9	12		t	2026-03-23 19:59:09.140058	2026-03-23 19:59:09.140059
6	10	\N	2026-03-28	9	12		t	2026-03-23 19:59:09.14006	2026-03-23 19:59:09.140061
7	10	\N	2026-03-30	9	12		t	2026-03-23 19:59:09.140063	2026-03-23 19:59:09.140064
8	10	\N	2026-03-31	9	12		t	2026-03-23 19:59:09.140065	2026-03-23 19:59:09.140067
9	10	\N	2026-03-26	10	5	fade	t	2026-03-23 21:17:48.551745	2026-03-23 21:17:48.55175
10	10	\N	2026-03-25	9	12	fade	t	2026-03-23 21:21:50.108388	2026-03-23 21:21:50.108392
11	10	\N	2026-03-25	2	10	faids	t	2026-03-23 21:41:21.851396	2026-03-23 21:41:21.851414
12	10	\N	2026-03-26	2	10	faids	t	2026-03-23 21:41:21.851425	2026-03-23 21:41:21.85143
13	10	\N	2026-03-27	2	10	faids	t	2026-03-23 21:41:21.851436	2026-03-23 21:41:21.851441
14	10	\N	2026-03-28	2	10	faids	t	2026-03-23 21:41:21.851446	2026-03-23 21:41:21.85145
15	10	\N	2026-03-30	2	10	faids	t	2026-03-23 21:41:21.851456	2026-03-23 21:41:21.85146
16	10	\N	2026-03-31	2	10	faids	t	2026-03-23 21:41:21.851465	2026-03-23 21:41:21.851469
17	10	\N	2026-03-26	2	9	faids	t	2026-03-23 21:42:29.218282	2026-03-23 21:42:29.218294
18	10	\N	2026-03-26	2	8	make up\n	t	2026-03-23 22:22:58.548889	2026-03-23 22:22:58.548898
19	10	\N	2026-03-24	2	11		t	2026-03-23 23:33:11.919353	2026-03-23 23:33:11.919394
20	10	\N	2026-03-25	2	11		t	2026-03-23 23:33:11.919413	2026-03-23 23:33:11.919419
21	10	\N	2026-03-26	2	11		t	2026-03-23 23:33:11.919429	2026-03-23 23:33:11.919435
22	10	\N	2026-03-27	2	11		t	2026-03-23 23:33:11.919442	2026-03-23 23:33:11.919549
23	10	\N	2026-03-28	2	11		t	2026-03-23 23:33:11.919571	2026-03-23 23:33:11.919583
24	10	1	2026-03-24	14	23		t	2026-03-24 00:15:56.908085	2026-03-24 00:15:56.908091
25	10	1	2026-03-25	14	23		t	2026-03-24 00:15:56.908094	2026-03-24 00:15:56.908095
26	10	1	2026-03-26	14	23		t	2026-03-24 00:15:56.908096	2026-03-24 00:15:56.908097
27	10	1	2026-03-27	14	23		t	2026-03-24 00:15:56.908098	2026-03-24 00:15:56.908099
28	10	1	2026-03-28	14	23		t	2026-03-24 00:15:56.908101	2026-03-24 00:15:56.908102
29	10	1	2026-03-25	14	23	all day	t	2026-03-24 00:35:49.279358	2026-03-24 00:35:49.279366
30	10	1	2026-03-26	14	23	all day	t	2026-03-24 00:35:49.279369	2026-03-24 00:35:49.279371
31	10	1	2026-03-27	14	23	all day	t	2026-03-24 00:35:49.279373	2026-03-24 00:35:49.279375
32	10	1	2026-03-28	14	23	all day	t	2026-03-24 00:35:49.279378	2026-03-24 00:35:49.27938
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.invoice_items (id, invoice_id, enrollment_id, description, quantity, unit_price, amount, created_at, updated_at) FROM stdin;
29	29	32	Course: Men's Barber	1	2000.00	2000.00	2026-03-31 08:41:14.898868	2026-03-31 08:41:14.898906
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.invoices (id, invoice_number, student_id, issue_date, due_date, total_amount, discount_amount, tax_amount, grand_total, status, notes, pdf_url, created_by, created_at, updated_at) FROM stdin;
18	INV-2026-9264D2	1	2026-03-15	\N	7100.00	0.00	0.00	7100.00	COMPLETED	\N	/uploads/invoices/INV-2026-9264D2_paid.pdf	3	2026-03-15 12:10:24.202204	2026-03-15 12:11:05.660852
19	INV-2026-642987	2	2026-03-15	\N	5000.00	0.00	0.00	5000.00	COMPLETED	\N	/uploads/invoices/INV-2026-642987_paid.pdf	3	2026-03-15 12:12:39.521762	2026-03-15 12:12:56.036383
20	INV-2026-B65233	1	2026-03-15	\N	4997.00	0.00	0.00	4997.00	COMPLETED	\N	/uploads/invoices/INV-2026-B65233_paid.pdf	3	2026-03-15 12:16:59.257164	2026-03-15 12:17:25.579071
1	INV-2026-5BA210	1	2026-03-07	\N	4999.00	0.00	0.00	4999.00	DRAFT	\N	\N	3	2026-03-07 20:09:31.692402	2026-03-07 20:09:31.692417
2	INV-2026-2ED900	1	2026-03-08	\N	5000.00	0.00	0.00	5000.00	DRAFT	\N	\N	3	2026-03-08 07:17:25.811648	2026-03-08 07:17:25.811653
3	INV-2026-5E4593	1	2026-03-08	\N	7800.00	0.00	0.00	7800.00	DRAFT	\N	\N	3	2026-03-08 07:58:26.527277	2026-03-08 07:58:26.52728
4	INV-2026-365760	1	2026-03-08	\N	10000.00	0.00	0.00	10000.00	DRAFT	\N	\N	3	2026-03-08 08:06:09.874516	2026-03-08 08:06:09.874519
5	INV-2026-9EDB43	1	2026-03-08	\N	250.00	0.00	0.00	250.00	DRAFT	\N	\N	3	2026-03-08 08:27:13.600112	2026-03-08 08:27:13.600116
6	INV-2026-3B5C30	1	2026-03-08	\N	300.00	0.00	0.00	300.00	DRAFT	\N	\N	3	2026-03-08 08:47:47.143805	2026-03-08 08:47:47.143813
7	INV-2026-39B5CC	1	2026-03-08	\N	98.00	0.00	0.00	98.00	DRAFT	\N	\N	3	2026-03-08 08:57:59.168053	2026-03-08 08:57:59.168077
8	INV-2026-4A2DEC	1	2026-03-08	\N	5000.00	0.00	0.00	5000.00	DRAFT	\N	\N	3	2026-03-08 09:19:04.139307	2026-03-08 09:19:04.139318
9	INV-2026-FF4A30	1	2026-03-08	\N	5000.00	0.00	0.00	5000.00	DRAFT	\N	/uploads/invoices/INV-2026-FF4A30.pdf	3	2026-03-08 09:30:09.081512	2026-03-08 09:30:09.984637
10	INV-2026-609A12	1	2026-03-08	\N	14999.00	0.00	0.00	14999.00	DRAFT	\N	/uploads/invoices/INV-2026-609A12.pdf	3	2026-03-08 11:11:35.132806	2026-03-08 11:11:36.439721
11	INV-2026-7077E0	1	2026-03-08	\N	6000.00	0.00	0.00	6000.00	DRAFT	\N	/uploads/invoices/INV-2026-7077E0.pdf	3	2026-03-08 12:49:03.141332	2026-03-08 12:49:03.425177
12	INV-2026-71E4E3	1	2026-03-08	\N	7500.00	0.00	0.00	7500.00	COMPLETED	\N	/uploads/invoices/INV-2026-71E4E3.pdf	3	2026-03-08 13:34:02.428711	2026-03-08 13:34:31.421335
21	INV-2026-18A609	1	2026-03-24	\N	7500.00	0.00	0.00	7500.00	COMPLETED	\N	/uploads/invoices/INV-2026-18A609_paid.pdf	3	2026-03-24 01:23:27.384862	2026-03-27 08:07:33.578228
13	INV-2026-96D1FB	1	2026-03-15	\N	10500.00	0.00	0.00	10500.00	COMPLETED	\N	/uploads/invoices/INV-2026-96D1FB_paid.pdf	3	2026-03-15 10:29:34.824037	2026-03-15 10:31:59.460567
14	INV-2026-F976B9	2	2026-03-15	\N	1000.00	0.00	0.00	1000.00	COMPLETED	\N	/uploads/invoices/INV-2026-F976B9_paid.pdf	3	2026-03-15 10:33:56.939936	2026-03-15 10:35:24.642885
22	INV-2026-596A6E	1	2026-03-29	\N	7650.00	0.00	0.00	7650.00	DRAFT	\N	/uploads/invoices/INV-2026-596A6E.pdf	3	2026-03-29 16:30:11.041365	2026-03-29 16:30:12.40716
15	INV-2026-889FF1	1	2026-03-15	\N	9950.00	0.00	0.00	9950.00	COMPLETED	\N	/uploads/invoices/INV-2026-889FF1_paid.pdf	3	2026-03-15 11:29:11.369051	2026-03-15 11:30:29.661129
16	INV-2026-D57693	2	2026-03-15	\N	4000.00	0.00	0.00	4000.00	COMPLETED	\N	/uploads/invoices/INV-2026-D57693_paid.pdf	3	2026-03-15 11:44:00.77457	2026-03-15 11:53:33.464717
23	INV-2026-B753EB	1	2026-03-30	\N	8000.00	0.00	0.00	8000.00	DRAFT	\N	/uploads/invoices/INV-2026-B753EB.pdf	3	2026-03-30 15:47:49.52316	2026-03-30 15:47:50.395746
17	INV-2026-843621	2	2026-03-15	\N	1500.00	0.00	0.00	1500.00	COMPLETED	\N	/uploads/invoices/INV-2026-843621_paid.pdf	3	2026-03-15 11:58:26.126168	2026-03-15 11:59:11.609126
24	INV-2026-B62AF4	1	2026-03-30	\N	7599.00	0.00	0.00	7599.00	DRAFT	\N	/uploads/invoices/INV-2026-B62AF4.pdf	3	2026-03-30 16:49:13.341772	2026-03-30 16:49:13.65234
25	INV-2026-B44B60	1	2026-03-30	\N	5000.00	0.00	0.00	5000.00	DRAFT	\N	/uploads/invoices/INV-2026-B44B60.pdf	3	2026-03-30 17:07:45.416763	2026-03-30 17:07:46.465147
26	INV-2026-E9E67E	1	2026-03-30	\N	1000.00	0.00	0.00	1000.00	DRAFT	\N	/uploads/invoices/INV-2026-E9E67E.pdf	3	2026-03-30 17:17:40.513686	2026-03-30 17:17:40.871944
27	INV-2026-2E16F0	1	2026-03-30	\N	7494.00	0.00	0.00	7494.00	DRAFT	\N	/uploads/invoices/INV-2026-2E16F0.pdf	3	2026-03-30 17:34:42.712791	2026-03-30 17:34:42.983466
28	INV-2026-D7BBC5	1	2026-03-30	\N	9999.00	0.00	0.00	9999.00	DRAFT	\N	/uploads/invoices/INV-2026-D7BBC5.pdf	3	2026-03-30 18:30:46.993746	2026-03-30 18:30:47.88943
29	INV-2026-CACEAD	1	2026-03-31	\N	2000.00	0.00	0.00	2000.00	SENT	\N	/uploads/invoices/INV-2026-CACEAD.pdf	3	2026-03-31 08:41:14.852178	2026-03-31 08:41:20.03017
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.notifications (id, user_id, type, title, message, link, is_read, created_by, read_at, created_at) FROM stdin;
4	4	enrollment	❌ Enrollment Cancelled	Your enrollment in 'womens herdressing' has been cancelled.	/student/courses	t	3	2026-03-29 17:54:25.153408	2026-03-29 17:50:45.368066
3	4	enrollment	✅ You're Enrolled!	Welcome! You've been successfully enrolled in womens herdressing. Ready to start learning?	/student/courses	t	3	2026-03-29 17:54:26.37875	2026-03-29 16:30:12.432464
8	5	student	✅ Profile Updated	Your Full Name, Phone Number, Email Address and 17 more fields have been updated successfully.	/student/profile	f	3	\N	2026-03-29 17:57:09.821533
9	5	student	✅ Profile Updated	Your Full Name, Phone Number, Email Address and 17 more fields have been updated successfully.	/student/profile	f	3	\N	2026-03-29 17:57:32.38515
11	7	course	✏️ Course Updated	Course 'makeup work' has been updated. Changes: name, level, is_active.	/admin/courses	f	3	\N	2026-03-29 18:26:34.824681
12	8	course	✏️ Course Updated	Course 'makeup work' has been updated. Changes: name, level, is_active.	/admin/courses	f	3	\N	2026-03-29 18:26:34.833985
21	3	admin_broadcast	🗑️ Enrollment Deleted	selam tesfaye samson Kiya aman's enrollment in 'Men's Barber' has been deleted.	/admin/enrollments	t	3	2026-03-30 15:48:07.383037	2026-03-30 15:47:00.380061
23	4	enrollment	❌ Enrollment Cancelled	Your enrollment in 'Men's Barber' has been cancelled.	/student/courses	f	3	\N	2026-03-30 16:48:45.985368
25	4	enrollment	✅ You're Enrolled!	You have enrolled in 'makeup'. Welcome aboard!	/student/courses	f	3	\N	2026-03-30 16:49:13.658239
24	3	admin_broadcast	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'Men's Barber' has been deleted.	/admin/enrollments	t	3	2026-03-30 16:49:29.112322	2026-03-30 16:48:46.005764
6	7	enrollment	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'womens herdressing' has been deleted.	/admin/enrollments	f	3	\N	2026-03-29 17:50:45.404111
7	8	enrollment	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'womens herdressing' has been deleted.	/admin/enrollments	f	3	\N	2026-03-29 17:50:45.413868
26	4	enrollment	❌ Enrollment Cancelled	Your enrollment in 'makeup' has been cancelled.	/student/courses	f	3	\N	2026-03-30 17:07:13.723869
2	4	student	✅ Profile Updated	Your full_name, phone, email, date_of_birth, gender, emergency_contact_name, emergency_contact_phone, emergency_contact_relation, address_line1, address_line2, city, state, postal_code, country, enrollment_status, enrollment_date, graduation_date, program_type, referral_source, notes has been successfully updated. Looking good!	/student/profile	t	3	2026-03-29 17:54:23.519181	2026-03-29 09:12:41.448046
13	4	student	✅ Profile Updated	Your Full Name, Phone Number, Email Address and 17 more fields have been updated successfully.	/student/profile	f	3	\N	2026-03-29 18:39:39.729841
14	5	student	✅ Profile Updated	Your Full Name, Phone Number, Email Address and 17 more fields have been updated successfully.	/student/profile	f	3	\N	2026-03-29 18:43:06.214315
15	4	student	✅ Profile Updated	Your Full Name, Phone Number, Email Address and 17 more fields have been updated successfully.	/student/profile	t	3	2026-03-29 19:06:25.908331	2026-03-29 18:51:08.165524
17	7	course	✏️ Course Updated	Course 'womens herdressing' has been updated. Changes: name, description, duration_text, level, is_active.	/admin/courses	f	3	\N	2026-03-29 19:22:40.861803
18	8	course	✏️ Course Updated	Course 'womens herdressing' has been updated. Changes: name, description, duration_text, level, is_active.	/admin/courses	f	3	\N	2026-03-29 19:22:40.867921
19	3	admin_broadcast	✏️ Course Updated	Course 'makeup' has been updated. Changes: name, level, is_active.	/admin/courses	t	3	2026-03-29 19:55:41.064103	2026-03-29 19:54:59.106032
5	3	enrollment	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'womens herdressing' has been deleted.	/admin/enrollments	t	3	2026-03-29 19:56:05.533378	2026-03-29 17:50:45.39489
10	3	course	✏️ Course Updated	Course 'makeup work' has been updated. Changes: name, level, is_active.	/admin/courses	t	3	2026-03-29 19:56:06.732235	2026-03-29 18:26:34.802445
16	3	course	✏️ Course Updated	Course 'womens herdressing' has been updated. Changes: name, description, duration_text, level, is_active.	/admin/courses	t	3	2026-03-29 19:56:07.746855	2026-03-29 19:22:40.850113
20	5	enrollment	❌ Enrollment Cancelled	Your enrollment in 'Men's Barber' has been cancelled.	/student/courses	f	3	\N	2026-03-30 15:47:00.356902
22	4	enrollment	✅ You're Enrolled!	You have enrolled in 'Men's Barber'. Welcome aboard!	/student/courses	f	3	\N	2026-03-30 15:47:50.410598
33	3	admin_broadcast	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'Men's Barber' has been deleted.	/admin/enrollments	t	3	2026-03-30 17:52:21.794355	2026-03-30 17:34:15.648315
30	3	admin_broadcast	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'womens herdressing' has been deleted.	/admin/enrollments	t	3	2026-03-30 17:52:22.936502	2026-03-30 17:17:14.00139
27	3	admin_broadcast	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'makeup' has been deleted.	/admin/enrollments	t	3	2026-03-30 17:52:23.734843	2026-03-30 17:07:13.761474
36	3	admin_broadcast	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'womens herdressing' has been deleted.	/admin/enrollments	f	3	\N	2026-03-30 18:30:21.727738
38	3	admin_broadcast	📝 New Enrollment	dawit alemu kassu has enrolled in 'makeup'.	/admin/enrollments	f	3	\N	2026-03-30 18:30:47.91881
40	3	admin_broadcast	🗑️ Enrollment Deleted	dawit alemu kassu's enrollment in 'makeup' has been deleted.	/admin/enrollments	f	3	\N	2026-03-31 08:40:51.52724
42	3	admin_broadcast	📝 New Enrollment	dawit alemu kassu has enrolled in 'Men's Barber'.	/admin/enrollments	f	3	\N	2026-03-31 08:41:20.1323
44	4	payment	📧 Invoice Sent	Invoice (INV-2026-CACEAD) for 2000.00 has been sent to your email.	/student/invoices	t	3	2026-03-31 08:59:33.365059	2026-03-31 08:41:20.220064
41	4	enrollment	✅ You're Enrolled!	You have enrolled in 'Men's Barber'. Welcome aboard!	/student/courses	t	3	2026-03-31 08:59:34.526293	2026-03-31 08:41:20.079275
39	4	enrollment	❌ Enrollment Cancelled	Your enrollment in 'makeup' has been cancelled.	/student/courses	t	3	2026-03-31 08:59:35.318712	2026-03-31 08:40:51.473121
37	4	enrollment	✅ You're Enrolled!	You have enrolled in 'makeup'. Welcome aboard!	/student/courses	t	3	2026-03-31 08:59:36.520994	2026-03-30 18:30:47.904707
35	4	enrollment	❌ Enrollment Cancelled	Your enrollment in 'womens herdressing' has been cancelled.	/student/courses	t	3	2026-03-31 08:59:37.215354	2026-03-30 18:30:21.704838
34	4	enrollment	✅ You're Enrolled!	You have enrolled in 'womens herdressing'. Welcome aboard!	/student/courses	t	3	2026-03-31 08:59:38.328376	2026-03-30 17:34:42.988392
32	4	enrollment	❌ Enrollment Cancelled	Your enrollment in 'Men's Barber' has been cancelled.	/student/courses	t	3	2026-03-31 08:59:39.024667	2026-03-30 17:34:15.626648
31	4	enrollment	✅ You're Enrolled!	You have enrolled in 'Men's Barber'. Welcome aboard!	/student/courses	t	3	2026-03-31 08:59:40.044064	2026-03-30 17:17:40.878964
29	4	enrollment	❌ Enrollment Cancelled	Your enrollment in 'womens herdressing' has been cancelled.	/student/courses	t	3	2026-03-31 08:59:40.782931	2026-03-30 17:17:13.980085
28	4	enrollment	✅ You're Enrolled!	You have enrolled in 'womens herdressing'. Welcome aboard!	/student/courses	t	3	2026-03-31 08:59:41.906259	2026-03-30 17:07:46.486434
43	3	admin_broadcast	📧 Invoice Sent	Invoice (INV-2026-CACEAD) for 2000.00 has been sent to dawit alemu kassu.	/admin/invoices	t	3	2026-03-31 08:41:44.898286	2026-03-31 08:41:20.204004
45	3	admin_broadcast	🗑️ Document Deleted	dawit alemu kassu's 'DocumentType.PROFILE_PHOTO' document has been deleted.	/admin/documents/1	f	3	\N	2026-04-02 20:27:53.007333
46	3	admin_broadcast	🗑️ Document Deleted	dawit alemu kassu's 'DocumentType.NATIONAL_ID' document has been deleted.	/admin/documents/1	f	3	\N	2026-04-02 20:27:57.171
47	3	admin_broadcast	📎 Document Uploaded	dawit alemu kassu has uploaded a 'DocumentType.PROFILE_PHOTO' document.	/admin/documents/1	f	3	\N	2026-04-02 20:32:05.482238
48	4	document	✅ Document Uploaded	Your 'DocumentType.PROFILE_PHOTO' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-02 20:32:05.492901
49	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-02 20:32:35.349219
50	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-02 20:39:21.541031
51	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-02 20:42:51.833143
52	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-02 20:46:42.879849
53	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-02 21:03:30.737039
54	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-02 21:14:11.706936
55	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-02 21:20:30.873849
56	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 13:59:40.480211
57	3	admin_broadcast	🗑️ Document Deleted	dawit alemu kassu's 'DocumentType.PROFILE_PHOTO' document has been deleted.	/admin/documents/1	f	3	\N	2026-04-03 14:26:29.854334
58	3	admin_broadcast	📎 Document Uploaded	dawit alemu kassu has uploaded a 'DocumentType.PROFILE_PHOTO' document.	/admin/documents/1	f	3	\N	2026-04-03 14:26:43.854371
59	4	document	✅ Document Uploaded	Your 'DocumentType.PROFILE_PHOTO' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-03 14:26:43.862196
60	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 14:27:09.788362
61	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 14:31:18.148647
62	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 14:34:30.565063
63	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 14:36:58.956451
64	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 14:40:56.143297
65	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 14:42:56.142234
66	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 14:46:02.067315
67	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 14:48:29.940776
68	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 15:02:27.404234
69	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 15:06:23.716201
70	3	admin_broadcast	🗑️ Document Deleted	dawit alemu kassu's 'DocumentType.PROFILE_PHOTO' document has been deleted.	/admin/documents/1	f	3	\N	2026-04-03 15:12:08.872641
71	3	admin_broadcast	📎 Document Uploaded	dawit alemu kassu has uploaded a 'DocumentType.PROFILE_PHOTO' document.	/admin/documents/1	f	3	\N	2026-04-03 15:12:20.921711
72	4	document	✅ Document Uploaded	Your 'DocumentType.PROFILE_PHOTO' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-03 15:12:20.92705
73	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-03 15:13:21.919016
74	3	admin_broadcast	🗑️ Document Deleted	dawit alemu kassu's 'DocumentType.PROFILE_PHOTO' document has been deleted.	/admin/documents/1	f	3	\N	2026-04-04 13:42:35.613282
75	3	admin_broadcast	📎 Document Uploaded	dawit alemu kassu has uploaded a 'DocumentType.PROFILE_PHOTO' document.	/admin/documents/1	f	3	\N	2026-04-04 13:48:17.833373
76	4	document	✅ Document Uploaded	Your 'DocumentType.PROFILE_PHOTO' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-04 13:48:17.851302
77	3	admin_broadcast	🗑️ Document Deleted	dawit alemu kassu's 'DocumentType.PROFILE_PHOTO' document has been deleted.	/admin/documents/1	f	3	\N	2026-04-04 14:47:07.645532
78	3	admin_broadcast	📎 Document Uploaded	dawit alemu kassu has uploaded a 'DocumentType.PROFILE_PHOTO' document.	/admin/documents/1	f	3	\N	2026-04-04 14:47:21.047007
79	4	document	✅ Document Uploaded	Your 'DocumentType.PROFILE_PHOTO' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-04 14:47:21.053296
80	4	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-04 14:52:38.742897
81	3	admin_broadcast	🗑️ Document Deleted	selam tesfaye samson Kiya aman's 'DocumentType.PROFILE_PHOTO' document has been deleted.	/admin/documents/2	f	3	\N	2026-04-04 15:03:48.497653
82	3	admin_broadcast	📎 Document Uploaded	selam tesfaye samson Kiya aman has uploaded a 'DocumentType.PROFILE_PHOTO' document.	/admin/documents/2	f	3	\N	2026-04-04 15:04:00.233283
83	5	document	✅ Document Uploaded	Your 'DocumentType.PROFILE_PHOTO' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-04 15:04:00.239969
84	5	certificate	🏆 Certificate Ready!	Your certificate for 'Men's Barber' is now available.	/student/certificates	f	3	\N	2026-04-04 15:07:10.822325
85	3	admin_broadcast	📎 Document Uploaded	dawit alemu kassu has uploaded a 'DocumentType.GRADE_REPORT' document.	/admin/documents/1	f	3	\N	2026-04-04 16:49:54.394681
86	4	document	✅ Document Uploaded	Your 'DocumentType.GRADE_REPORT' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-04 16:49:54.411521
87	3	admin_broadcast	📎 Document Uploaded	selam tesfaye samson Kiya aman has uploaded a 'DocumentType.EXPERIENCE_LETTER' document.	/admin/documents/2	f	3	\N	2026-04-04 18:24:43.836189
88	5	document	✅ Document Uploaded	Your 'DocumentType.EXPERIENCE_LETTER' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-04 18:24:43.852375
89	3	admin_broadcast	📎 Document Uploaded	dawit alemu kassu has uploaded a 'DocumentType.EXPERIENCE_LETTER' document.	/admin/documents/1	f	3	\N	2026-04-04 18:25:09.956127
90	4	document	✅ Document Uploaded	Your 'DocumentType.EXPERIENCE_LETTER' document has been uploaded successfully.	/student/documents	f	3	\N	2026-04-04 18:25:09.965005
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.payment_methods (id, name, description, is_active, created_at, updated_at) FROM stdin;
1	Cash	Cash payment	t	2026-03-07 17:23:21.385122	2026-03-07 17:23:21.385138
2	Bank Transfer	Direct bank transfer	t	2026-03-07 17:23:21.421024	2026-03-07 17:23:21.421037
3	Mobile Money	Mobile money transfer (M-Pesa, etc.)	t	2026-03-07 17:23:21.432796	2026-03-07 17:23:21.432807
4	Cheque	Cheque payment	t	2026-03-07 17:23:21.439774	2026-03-07 17:23:21.439787
5	Credit Card	Credit/Debit card payment	t	2026-03-07 17:23:21.451887	2026-03-07 17:23:21.4519
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.payments (id, student_id, enrollment_id, invoice_id, amount, payment_date, payment_method_id, transaction_reference, status, notes, recorded_by, created_at, updated_at) FROM stdin;
4	1	\N	1	2999.00	2026-03-07	1	pay	COMPLETED	half payment	3	2026-03-07 21:09:58.999872	2026-03-08 07:16:49.594424
5	1	\N	1	999.99	2026-03-07	1	pay	COMPLETED	\N	3	2026-03-07 22:22:50.672161	2026-03-08 07:16:49.594499
6	1	\N	1	999.99	2026-03-07	1	pay	COMPLETED	\N	3	2026-03-07 22:23:22.633038	2026-03-08 07:16:49.594505
7	1	\N	1	0.01	2026-03-07	2	pay it	COMPLETED	\N	3	2026-03-07 22:36:11.531392	2026-03-08 07:16:49.594507
8	1	\N	1	1.00	2026-03-07	2	\N	COMPLETED	\N	3	2026-03-07 22:37:04.780252	2026-03-08 07:16:49.59451
9	1	\N	9	5000.00	2026-03-08	2	\N	COMPLETED	\N	3	2026-03-08 11:09:25.90923	2026-03-08 11:10:34.056148
15	1	\N	\N	14000.00	2026-03-08	3	wueuedjdjeje	COMPLETED	paid!	3	2026-03-08 12:38:19.419861	2026-03-08 12:38:19.419889
10	1	\N	10	14999.00	2026-03-08	2	pay	COMPLETED	\N	3	2026-03-08 11:23:14.186221	2026-03-08 12:46:23.715926
11	1	\N	10	14999.00	2026-03-08	2	\N	COMPLETED	\N	3	2026-03-08 11:57:40.0419	2026-03-08 12:46:23.715932
12	1	\N	10	14999.00	2026-03-08	2	\N	COMPLETED	\N	3	2026-03-08 11:59:43.809614	2026-03-08 12:46:23.715934
13	1	\N	10	14999.00	2026-03-08	2	\N	COMPLETED	\N	3	2026-03-08 12:03:42.622246	2026-03-08 12:46:23.715935
14	1	\N	10	14999.00	2026-03-08	2	\N	COMPLETED	\N	3	2026-03-08 12:05:23.602704	2026-03-08 12:46:23.715937
16	1	\N	11	6000.00	2026-03-08	1	\N	COMPLETED	\N	3	2026-03-08 12:50:04.803158	2026-03-08 13:31:49.730135
22	2	\N	17	1500.00	2026-03-15	3	\N	COMPLETED	\N	3	2026-03-15 11:59:11.403281	2026-03-15 12:06:43.441604
21	2	\N	16	4000.00	2026-03-15	2	\N	COMPLETED	\N	3	2026-03-15 11:53:33.237304	2026-03-15 12:06:47.583815
20	1	\N	15	9950.00	2026-03-15	2	124	COMPLETED	paid	3	2026-03-15 11:30:29.450156	2026-03-15 12:06:50.922069
19	2	\N	14	1000.00	2026-03-15	1	\N	COMPLETED	\N	3	2026-03-15 10:35:24.083074	2026-03-15 12:06:54.420155
18	1	\N	13	10500.00	2026-03-15	2	231	COMPLETED	\N	3	2026-03-15 10:31:59.269491	2026-03-15 12:06:57.49616
17	1	\N	12	7500.00	2026-03-08	1	\N	COMPLETED	\N	3	2026-03-08 13:34:31.389954	2026-03-15 12:07:00.907106
25	1	\N	20	4997.00	2026-03-15	2	23ew3	COMPLETED	\N	3	2026-03-15 12:17:25.406447	2026-03-23 13:22:06.160048
23	1	\N	18	7100.00	2026-03-15	2	#12431	COMPLETED	paid in full	3	2026-03-15 12:11:05.415796	2026-03-24 01:22:44.177251
26	1	\N	21	7500.00	2026-03-27	2	#4etrwte54tw4	COMPLETED	\N	3	2026-03-27 08:07:32.356461	2026-03-29 16:28:07.646935
24	2	\N	19	5000.00	2026-03-15	1	\N	COMPLETED	\N	3	2026-03-15 12:12:55.688329	2026-03-30 15:47:00.316166
\.


--
-- Data for Name: student_documents; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.student_documents (id, student_id, document_type, file_name, file_path, file_size, mime_type, description, uploaded_by, uploaded_at, is_active) FROM stdin;
46	1	PROFILE_PHOTO	prof.jpg	uploads/students/1/profile_photo/20260404_144721_prof.jpg	12232	image/jpeg	\N	3	2026-04-04 14:47:21.020196	t
47	1	PROFILE_PHOTO	jhon.jpg	uploads/students/1/profile_photo/20260404_145009_jhon.jpg	6215	image/jpeg	\N	4	2026-04-04 14:50:09.465186	t
48	2	PROFILE_PHOTO	jhon.jpg	uploads/students/2/profile_photo/20260404_150400_jhon.jpg	6215	image/jpeg	\N	3	2026-04-04 15:04:00.211269	f
49	2	PROFILE_PHOTO	prof.jpg	uploads/students/2/profile_photo/20260404_150438_prof.jpg	12232	image/jpeg	\N	5	2026-04-04 15:04:38.453795	t
50	1	GRADE_REPORT	3278785_486497-PH67YJ-500 (1).jpg	uploads/students/1/grade_report/20260404_164954_3278785_486497-PH67YJ-500 (1).jpg	619403	image/jpeg	\N	3	2026-04-04 16:49:54.297046	t
51	2	EXPERIENCE_LETTER	3278785_486497-PH67YJ-500.jpg	uploads/students/2/EXPERIENCE_LETTER/20260404_182443_3278785_486497-PH67YJ-500.jpg	619403	image/jpeg	\N	3	2026-04-04 18:24:43.741966	t
52	1	EXPERIENCE_LETTER	images (7).jpg	uploads/students/1/EXPERIENCE_LETTER/20260404_182509_images (7).jpg	5733	image/jpeg	\N	3	2026-04-04 18:25:09.936377	t
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.students (id, user_id, date_of_birth, gender, emergency_contact_name, emergency_contact_phone, emergency_contact_relation, address_line1, address_line2, city, state, postal_code, country, enrollment_status, enrollment_date, graduation_date, program_type, referral_source, notes, created_at, updated_at) FROM stdin;
2	5	2003-06-10	FEMALE	Ermias Mesfin Abebe	0912246515	friend	Shashemene	abosto	shashemene	oromia	1000	Ethiopia	ACTIVE	2026-03-08	\N	womens herdressing	friend	\N	2026-03-08 17:03:54.700578	2026-03-29 18:43:06.159755
1	4	2007-12-31	FEMALE	Ermias Mesfin Abebe LEMA Gemeso	0912246515	brother	Addis Ababa	\N	Addis Ababa	oromia	1000	Ethiopia	ACTIVE	2026-03-19	\N	Men's Barber	google	hi	2026-03-05 15:28:55.304943	2026-03-29 19:20:10.788062
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.users (id, email, password_hash, full_name, phone, profile_photo_url, bio, role, is_active, last_login, created_at, updated_at, is_email_verified, email_verified_at) FROM stdin;
8	admin2@mulat.com	$2b$12$8M5U6bvcxcYwsAbnGTdL/uzlRltVWomUTgdr77vk/nBKqrFdo2DPW	admin 2	+251976767676	\N	\N	ADMIN	t	2026-03-12 11:41:14.582419	2026-03-12 11:38:34.691197	2026-03-12 11:41:14.583102	f	\N
6	kiya@mulat.com	$2b$12$ADFpLdNBtQ/MviiXPZEPretAlCAETc8xnvwZd0Uyv.6/6jtGjIAp2	kiya admasu	0912246415	\N	\N	STUDENT	t	\N	2026-03-08 19:27:00.412051	2026-03-08 19:27:00.412061	f	\N
10	instructor@mulat.com	$2b$12$jId8bXLJUlX88IHLzaa7cekgXq4eeYbGgOE.dIR7DCvQi.JIoVwcq	Instructor	+2519000011	\N	\N	INSTRUCTOR	t	2026-03-28 02:01:26.406313	2026-03-23 12:33:11.906798	2026-03-28 02:01:26.407832	f	\N
7	admin@mulat.com	$2b$12$IEGMpzXN50QcoHkZSztTFOzrBWg/iZWbHrGpi57zYrg4yorleQbs.	Admin	+251970707070	\N	\N	ADMIN	t	2026-03-28 18:24:35.191437	2026-03-12 11:17:40.573669	2026-03-28 18:24:35.192125	f	\N
4	ermiasmesfinabebe@gmail.com	$2b$12$DWr0DRx3aFrd7ojUG14k5uTKG63MXfuPK8goxi1/311UGyW6XMZUO	dawit alemu kassu	+25156721234	/uploads/users/4/20260404_135507_images (7).jpg	\N	STUDENT	t	2026-04-04 14:47:39.94256	2026-03-05 15:28:55.187437	2026-04-04 14:47:39.943539	f	\N
5	selam@mulat.com	$2b$12$Ay11DovQdTgvc9J4udt/2.ZfOZzsKCmwBxcSVEgj/vNp06kUtrIDC	selam tesfaye samson Kiya aman	+251912241011	\N	\N	STUDENT	t	2026-04-04 15:04:17.432976	2026-03-08 17:03:54.679491	2026-04-04 15:04:17.434865	f	\N
3	ermias@mulat.com	$2b$12$.FCj6L3YduZeEc0l0W4CqOtZcs3nhN97xZ3pxi6kIuPkH./WnTumO	Ermias Admin	+251961537287	/uploads/users/3/20260307_105950_photo_7_2025-07-23_18-05-55.jpg	Admin	SUPER_ADMIN	t	2026-04-06 11:52:24.34076	2026-03-05 10:52:37.928315	2026-04-06 11:52:24.342941	f	\N
9	ermiimimim@gai.com	$2b$12$ro3/Sq70RW/Iwv81tKUlBemHAErWzuAJqiCA0GG8j.J34QUhNNqly	Ermias Mesfin Abebe	0912246515	\N	\N	INSTRUCTOR	t	\N	2026-03-12 11:39:25.46913	2026-03-12 11:39:25.469134	f	\N
\.


--
-- Name: admin_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.admin_permissions_id_seq', 2, true);


--
-- Name: attendance_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.attendance_requests_id_seq', 1, false);


--
-- Name: attendances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.attendances_id_seq', 3, true);


--
-- Name: certificate_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.certificate_templates_id_seq', 3, true);


--
-- Name: certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.certificates_id_seq', 33, true);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.courses_id_seq', 3, true);


--
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.email_logs_id_seq', 27, true);


--
-- Name: enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.enrollments_id_seq', 33, true);


--
-- Name: instructor_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.instructor_courses_id_seq', 1, true);


--
-- Name: instructor_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.instructor_schedules_id_seq', 32, true);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 29, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.invoices_id_seq', 29, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.notifications_id_seq', 90, true);


--
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 20, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.payments_id_seq', 26, true);


--
-- Name: student_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.student_documents_id_seq', 52, true);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.students_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: attendance_requests attendance_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendance_requests
    ADD CONSTRAINT attendance_requests_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: certificate_templates certificate_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificate_templates
    ADD CONSTRAINT certificate_templates_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: instructor_courses instructor_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_courses
    ADD CONSTRAINT instructor_courses_pkey PRIMARY KEY (id);


--
-- Name: instructor_schedules instructor_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_schedules
    ADD CONSTRAINT instructor_schedules_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: student_documents student_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.student_documents
    ADD CONSTRAINT student_documents_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_admin_permissions_admin_id; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX ix_admin_permissions_admin_id ON public.admin_permissions USING btree (admin_id);


--
-- Name: ix_admin_permissions_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_admin_permissions_id ON public.admin_permissions USING btree (id);


--
-- Name: ix_attendance_requests_course_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendance_requests_course_id ON public.attendance_requests USING btree (course_id);


--
-- Name: ix_attendance_requests_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendance_requests_id ON public.attendance_requests USING btree (id);


--
-- Name: ix_attendance_requests_requested_date; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendance_requests_requested_date ON public.attendance_requests USING btree (requested_date);


--
-- Name: ix_attendance_requests_schedule_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendance_requests_schedule_id ON public.attendance_requests USING btree (schedule_id);


--
-- Name: ix_attendance_requests_status; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendance_requests_status ON public.attendance_requests USING btree (status);


--
-- Name: ix_attendance_requests_student_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendance_requests_student_id ON public.attendance_requests USING btree (student_id);


--
-- Name: ix_attendances_course_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendances_course_id ON public.attendances USING btree (course_id);


--
-- Name: ix_attendances_date; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendances_date ON public.attendances USING btree (date);


--
-- Name: ix_attendances_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendances_id ON public.attendances USING btree (id);


--
-- Name: ix_attendances_instructor_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendances_instructor_id ON public.attendances USING btree (instructor_id);


--
-- Name: ix_attendances_status; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendances_status ON public.attendances USING btree (status);


--
-- Name: ix_attendances_student_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_attendances_student_id ON public.attendances USING btree (student_id);


--
-- Name: ix_certificate_templates_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_certificate_templates_id ON public.certificate_templates USING btree (id);


--
-- Name: ix_certificates_certificate_number; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX ix_certificates_certificate_number ON public.certificates USING btree (certificate_number);


--
-- Name: ix_certificates_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_certificates_id ON public.certificates USING btree (id);


--
-- Name: ix_certificates_status; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_certificates_status ON public.certificates USING btree (status);


--
-- Name: ix_certificates_student_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_certificates_student_id ON public.certificates USING btree (student_id);


--
-- Name: ix_courses_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_courses_id ON public.courses USING btree (id);


--
-- Name: ix_email_logs_email_type; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_email_logs_email_type ON public.email_logs USING btree (email_type);


--
-- Name: ix_email_logs_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_email_logs_id ON public.email_logs USING btree (id);


--
-- Name: ix_email_logs_recipient_email; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_email_logs_recipient_email ON public.email_logs USING btree (recipient_email);


--
-- Name: ix_email_logs_status; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_email_logs_status ON public.email_logs USING btree (status);


--
-- Name: ix_enrollments_course_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_enrollments_course_id ON public.enrollments USING btree (course_id);


--
-- Name: ix_enrollments_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_enrollments_id ON public.enrollments USING btree (id);


--
-- Name: ix_enrollments_status; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_enrollments_status ON public.enrollments USING btree (status);


--
-- Name: ix_enrollments_student_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_enrollments_student_id ON public.enrollments USING btree (student_id);


--
-- Name: ix_instructor_courses_course_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_instructor_courses_course_id ON public.instructor_courses USING btree (course_id);


--
-- Name: ix_instructor_courses_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_instructor_courses_id ON public.instructor_courses USING btree (id);


--
-- Name: ix_instructor_courses_instructor_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_instructor_courses_instructor_id ON public.instructor_courses USING btree (instructor_id);


--
-- Name: ix_instructor_schedules_course_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_instructor_schedules_course_id ON public.instructor_schedules USING btree (course_id);


--
-- Name: ix_instructor_schedules_date; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_instructor_schedules_date ON public.instructor_schedules USING btree (date);


--
-- Name: ix_instructor_schedules_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_instructor_schedules_id ON public.instructor_schedules USING btree (id);


--
-- Name: ix_instructor_schedules_instructor_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_instructor_schedules_instructor_id ON public.instructor_schedules USING btree (instructor_id);


--
-- Name: ix_invoice_items_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_invoice_items_id ON public.invoice_items USING btree (id);


--
-- Name: ix_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_invoice_items_invoice_id ON public.invoice_items USING btree (invoice_id);


--
-- Name: ix_invoices_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_invoices_id ON public.invoices USING btree (id);


--
-- Name: ix_invoices_invoice_number; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX ix_invoices_invoice_number ON public.invoices USING btree (invoice_number);


--
-- Name: ix_invoices_status; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_invoices_status ON public.invoices USING btree (status);


--
-- Name: ix_invoices_student_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_invoices_student_id ON public.invoices USING btree (student_id);


--
-- Name: ix_notifications_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_notifications_id ON public.notifications USING btree (id);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_payment_methods_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_payment_methods_id ON public.payment_methods USING btree (id);


--
-- Name: ix_payments_enrollment_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_payments_enrollment_id ON public.payments USING btree (enrollment_id);


--
-- Name: ix_payments_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_payments_id ON public.payments USING btree (id);


--
-- Name: ix_payments_invoice_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_payments_invoice_id ON public.payments USING btree (invoice_id);


--
-- Name: ix_payments_status; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_payments_status ON public.payments USING btree (status);


--
-- Name: ix_payments_student_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_payments_student_id ON public.payments USING btree (student_id);


--
-- Name: ix_student_documents_document_type; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_student_documents_document_type ON public.student_documents USING btree (document_type);


--
-- Name: ix_student_documents_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_student_documents_id ON public.student_documents USING btree (id);


--
-- Name: ix_student_documents_student_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_student_documents_student_id ON public.student_documents USING btree (student_id);


--
-- Name: ix_students_enrollment_status; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_students_enrollment_status ON public.students USING btree (enrollment_status);


--
-- Name: ix_students_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_students_id ON public.students USING btree (id);


--
-- Name: ix_students_user_id; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX ix_students_user_id ON public.students USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: admin_permissions admin_permissions_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id);


--
-- Name: admin_permissions admin_permissions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: attendance_requests attendance_requests_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendance_requests
    ADD CONSTRAINT attendance_requests_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: attendance_requests attendance_requests_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendance_requests
    ADD CONSTRAINT attendance_requests_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.instructor_schedules(id);


--
-- Name: attendance_requests attendance_requests_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendance_requests
    ADD CONSTRAINT attendance_requests_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: attendances attendances_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: attendances attendances_instructor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_instructor_id_fkey FOREIGN KEY (instructor_id) REFERENCES public.users(id);


--
-- Name: attendances attendances_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: certificate_templates certificate_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificate_templates
    ADD CONSTRAINT certificate_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: certificates certificates_issued_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_issued_by_fkey FOREIGN KEY (issued_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: certificates certificates_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.certificate_templates(id);


--
-- Name: email_logs email_logs_related_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_related_user_id_fkey FOREIGN KEY (related_user_id) REFERENCES public.users(id);


--
-- Name: enrollments enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: enrollments enrollments_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: instructor_courses instructor_courses_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_courses
    ADD CONSTRAINT instructor_courses_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: instructor_courses instructor_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_courses
    ADD CONSTRAINT instructor_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: instructor_courses instructor_courses_instructor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_courses
    ADD CONSTRAINT instructor_courses_instructor_id_fkey FOREIGN KEY (instructor_id) REFERENCES public.users(id);


--
-- Name: instructor_schedules instructor_schedules_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_schedules
    ADD CONSTRAINT instructor_schedules_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: instructor_schedules instructor_schedules_instructor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.instructor_schedules
    ADD CONSTRAINT instructor_schedules_instructor_id_fkey FOREIGN KEY (instructor_id) REFERENCES public.users(id);


--
-- Name: invoice_items invoice_items_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.enrollments(id);


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoices invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: invoices invoices_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: notifications notifications_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payments payments_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.enrollments(id);


--
-- Name: payments payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: payments payments_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: payments payments_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.users(id);


--
-- Name: payments payments_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: student_documents student_documents_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.student_documents
    ADD CONSTRAINT student_documents_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: student_documents student_documents_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.student_documents
    ADD CONSTRAINT student_documents_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: students students_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict p2K7DtxNaGuF9Fi8qRTUBhMse429kSU6oRKfaDhLj4nVBo5reiz4HH7nTMvzCyE

